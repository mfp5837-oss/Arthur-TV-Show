var networks = {"4x3.tsv": {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "data" : {
    "shared_name" : "4x3.tsv",
    "name" : "4x3.tsv",
    "SUID" : 6883,
    "__Annotations" : [ "edgeThickness=3.0|canvas=foreground|fillOpacity=100.0|color=-16777216|rotation=0.0|type=org.cytoscape.view.presentation.annotations.BoundedTextAnnotation|fontStyle=1|uuid=07411bd1-1c43-493a-9388-705235ba06bc|shapeType=ROUNDEDRECTANGLE|edgeColor=-14342875|fontFamily=Serif|edgeOpacity=100.0|name=How many times a characters are mention in S4 E3|x=-762.787725817127|width=528.6015625|y=-294.59710439507086|z=1|fontSize=24|text=How many times a characters are mention in S4 E3|height=51.470386450891084" ],
    "selected" : true
  },
  "elements" : {
    "nodes" : [ {
      "data" : {
        "id" : "7204",
        "shared_name" : "5",
        "name" : "5",
        "SUID" : 7204,
        "selected" : false
      },
      "position" : {
        "x" : 10.176540149277766,
        "y" : -179.25997844708974
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7198",
        "shared_name" : "Vision of Buster",
        "name" : "Vision of Buster",
        "SUID" : 7198,
        "sceneMarker" : "scene",
        "selected" : false
      },
      "position" : {
        "x" : 262.2211598359261,
        "y" : 133.44684282052893
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7192",
        "shared_name" : "Vision of Arthur",
        "name" : "Vision of Arthur",
        "SUID" : 7192,
        "sceneMarker" : "scene",
        "selected" : false
      },
      "position" : {
        "x" : 180.77020072545798,
        "y" : 217.51482369287555
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7120",
        "shared_name" : "Prunella",
        "name" : "Prunella",
        "SUID" : 7120,
        "sceneMarker" : "scene",
        "selected" : false
      },
      "position" : {
        "x" : 305.30061038926897,
        "y" : 24.60822335119501
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7102",
        "shared_name" : "Brain",
        "name" : "Brain",
        "SUID" : 7102,
        "sceneMarker" : "scene",
        "selected" : false
      },
      "position" : {
        "x" : 73.34790322765046,
        "y" : 264.0135779585644
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7097",
        "shared_name" : "4",
        "name" : "4",
        "SUID" : 7097,
        "selected" : false
      },
      "position" : {
        "x" : 136.1988499926019,
        "y" : 52.09343218671958
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7049",
        "shared_name" : "Mrs. Baxter",
        "name" : "Mrs. Baxter",
        "SUID" : 7049,
        "sceneMarker" : "scene",
        "selected" : false
      },
      "position" : {
        "x" : -160.4171204269031,
        "y" : 217.5148236928751
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7040",
        "shared_name" : "3",
        "name" : "3",
        "SUID" : 7040,
        "selected" : false
      },
      "position" : {
        "x" : -97.55302326980967,
        "y" : 75.11598222170038
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7038",
        "shared_name" : "Muffy",
        "name" : "Muffy",
        "SUID" : 7038,
        "sceneMarker" : "scene",
        "selected" : false
      },
      "position" : {
        "x" : -52.99482292909583,
        "y" : 264.01357795856427
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7029",
        "shared_name" : "Umpire",
        "name" : "Umpire",
        "SUID" : 7029,
        "sceneMarker" : "scene",
        "selected" : false
      },
      "position" : {
        "x" : -280.95331615930803,
        "y" : -101.67135024560088
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7023",
        "shared_name" : "Francine",
        "name" : "Francine",
        "SUID" : 7023,
        "sceneMarker" : "scene",
        "selected" : false
      },
      "position" : {
        "x" : -241.86807953737093,
        "y" : 133.44684282052842
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "6981",
        "shared_name" : "Mr. Read",
        "name" : "Mr. Read",
        "SUID" : 6981,
        "sceneMarker" : "scene",
        "selected" : false
      },
      "position" : {
        "x" : -144.480783418641,
        "y" : -286.32244608250335
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "6972",
        "shared_name" : "D.W.",
        "name" : "D.W.",
        "SUID" : 6972,
        "sceneMarker" : "scene",
        "selected" : false
      },
      "position" : {
        "x" : -284.9475300907136,
        "y" : 24.608223351194543
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "6967",
        "shared_name" : "2",
        "name" : "2",
        "SUID" : 6967,
        "selected" : false
      },
      "position" : {
        "x" : -110.45260147289,
        "y" : -118.41495694800689
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "6961",
        "shared_name" : "Mrs. Read",
        "name" : "Mrs. Read",
        "SUID" : 6961,
        "sceneMarker" : "scene",
        "selected" : false
      },
      "position" : {
        "x" : -231.08174309505773,
        "y" : -207.569935448924
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "6955",
        "shared_name" : "Kate",
        "name" : "Kate",
        "SUID" : 6955,
        "sceneMarker" : "scene",
        "selected" : false
      },
      "position" : {
        "x" : 212.0125662005055,
        "y" : -251.21091579101744
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "6928",
        "shared_name" : "Buster",
        "name" : "Buster",
        "SUID" : 6928,
        "sceneMarker" : "scene",
        "selected" : false
      },
      "position" : {
        "x" : 303.45009655493186,
        "y" : -92.43134152546246
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "6913",
        "shared_name" : "1",
        "name" : "1",
        "SUID" : 6913,
        "selected" : false
      },
      "position" : {
        "x" : 111.09455317489162,
        "y" : -140.2354471190536
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "6911",
        "shared_name" : "Arthur",
        "name" : "Arthur",
        "SUID" : 6911,
        "sceneMarker" : "scene",
        "selected" : false
      },
      "position" : {
        "x" : 10.176540149277745,
        "y" : -29.259978447089747
      },
      "selected" : false
    } ],
    "edges" : [ {
      "data" : {
        "id" : "7201",
        "source" : "7198",
        "target" : "7097",
        "shared_name" : "Vision of Buster (interacts with) 4",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Vision of Buster (interacts with) 4",
        "interaction" : "interacts with",
        "SUID" : 7201,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7195",
        "source" : "7192",
        "target" : "7097",
        "shared_name" : "Vision of Arthur (interacts with) 4",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Vision of Arthur (interacts with) 4",
        "interaction" : "interacts with",
        "SUID" : 7195,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7129",
        "source" : "7120",
        "target" : "7097",
        "shared_name" : "Prunella (interacts with) 4",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Prunella (interacts with) 4",
        "interaction" : "interacts with",
        "SUID" : 7129,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7123",
        "source" : "7120",
        "target" : "7097",
        "shared_name" : "Prunella (interacts with) 4",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Prunella (interacts with) 4",
        "interaction" : "interacts with",
        "SUID" : 7123,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7105",
        "source" : "7102",
        "target" : "7097",
        "shared_name" : "Brain (interacts with) 4",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Brain (interacts with) 4",
        "interaction" : "interacts with",
        "SUID" : 7105,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7052",
        "source" : "7049",
        "target" : "7040",
        "shared_name" : "Mrs. Baxter (interacts with) 3",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Mrs. Baxter (interacts with) 3",
        "interaction" : "interacts with",
        "SUID" : 7052,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7043",
        "source" : "7038",
        "target" : "7040",
        "shared_name" : "Muffy (interacts with) 3",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Muffy (interacts with) 3",
        "interaction" : "interacts with",
        "SUID" : 7043,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7032",
        "source" : "7029",
        "target" : "6967",
        "shared_name" : "Umpire (interacts with) 2",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Umpire (interacts with) 2",
        "interaction" : "interacts with",
        "SUID" : 7032,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7094",
        "source" : "7023",
        "target" : "7040",
        "shared_name" : "Francine (interacts with) 3",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Francine (interacts with) 3",
        "interaction" : "interacts with",
        "SUID" : 7094,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7035",
        "source" : "7023",
        "target" : "6967",
        "shared_name" : "Francine (interacts with) 2",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Francine (interacts with) 2",
        "interaction" : "interacts with",
        "SUID" : 7035,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7026",
        "source" : "7023",
        "target" : "6967",
        "shared_name" : "Francine (interacts with) 2",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Francine (interacts with) 2",
        "interaction" : "interacts with",
        "SUID" : 7026,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7186",
        "source" : "6981",
        "target" : "7097",
        "shared_name" : "Mr. Read (interacts with) 4",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Mr. Read (interacts with) 4",
        "interaction" : "interacts with",
        "SUID" : 7186,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7153",
        "source" : "6981",
        "target" : "7097",
        "shared_name" : "Mr. Read (interacts with) 4",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Mr. Read (interacts with) 4",
        "interaction" : "interacts with",
        "SUID" : 7153,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7005",
        "source" : "6981",
        "target" : "6967",
        "shared_name" : "Mr. Read (interacts with) 2",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Mr. Read (interacts with) 2",
        "interaction" : "interacts with",
        "SUID" : 7005,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "6984",
        "source" : "6981",
        "target" : "6967",
        "shared_name" : "Mr. Read (interacts with) 2",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Mr. Read (interacts with) 2",
        "interaction" : "interacts with",
        "SUID" : 6984,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7329",
        "source" : "6972",
        "target" : "7204",
        "shared_name" : "D.W. (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "D.W. (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 7329,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7314",
        "source" : "6972",
        "target" : "7204",
        "shared_name" : "D.W. (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "D.W. (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 7314,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7308",
        "source" : "6972",
        "target" : "7204",
        "shared_name" : "D.W. (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "D.W. (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 7308,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7254",
        "source" : "6972",
        "target" : "7204",
        "shared_name" : "D.W. (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "D.W. (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 7254,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7245",
        "source" : "6972",
        "target" : "7204",
        "shared_name" : "D.W. (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "D.W. (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 7245,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7236",
        "source" : "6972",
        "target" : "7204",
        "shared_name" : "D.W. (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "D.W. (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 7236,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7230",
        "source" : "6972",
        "target" : "7204",
        "shared_name" : "D.W. (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "D.W. (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 7230,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7224",
        "source" : "6972",
        "target" : "7204",
        "shared_name" : "D.W. (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "D.W. (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 7224,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7206",
        "source" : "6972",
        "target" : "7204",
        "shared_name" : "D.W. (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "D.W. (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 7206,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7088",
        "source" : "6972",
        "target" : "7040",
        "shared_name" : "D.W. (interacts with) 3",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "D.W. (interacts with) 3",
        "interaction" : "interacts with",
        "SUID" : 7088,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7085",
        "source" : "6972",
        "target" : "7040",
        "shared_name" : "D.W. (interacts with) 3",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "D.W. (interacts with) 3",
        "interaction" : "interacts with",
        "SUID" : 7085,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7079",
        "source" : "6972",
        "target" : "7040",
        "shared_name" : "D.W. (interacts with) 3",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "D.W. (interacts with) 3",
        "interaction" : "interacts with",
        "SUID" : 7079,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7073",
        "source" : "6972",
        "target" : "7040",
        "shared_name" : "D.W. (interacts with) 3",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "D.W. (interacts with) 3",
        "interaction" : "interacts with",
        "SUID" : 7073,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7067",
        "source" : "6972",
        "target" : "7040",
        "shared_name" : "D.W. (interacts with) 3",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "D.W. (interacts with) 3",
        "interaction" : "interacts with",
        "SUID" : 7067,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7011",
        "source" : "6972",
        "target" : "6967",
        "shared_name" : "D.W. (interacts with) 2",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "D.W. (interacts with) 2",
        "interaction" : "interacts with",
        "SUID" : 7011,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7008",
        "source" : "6972",
        "target" : "6967",
        "shared_name" : "D.W. (interacts with) 2",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "D.W. (interacts with) 2",
        "interaction" : "interacts with",
        "SUID" : 7008,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "6990",
        "source" : "6972",
        "target" : "6967",
        "shared_name" : "D.W. (interacts with) 2",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "D.W. (interacts with) 2",
        "interaction" : "interacts with",
        "SUID" : 6990,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "6975",
        "source" : "6972",
        "target" : "6967",
        "shared_name" : "D.W. (interacts with) 2",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "D.W. (interacts with) 2",
        "interaction" : "interacts with",
        "SUID" : 6975,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7177",
        "source" : "6961",
        "target" : "7097",
        "shared_name" : "Mrs. Read (interacts with) 4",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Mrs. Read (interacts with) 4",
        "interaction" : "interacts with",
        "SUID" : 7177,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7061",
        "source" : "6961",
        "target" : "7040",
        "shared_name" : "Mrs. Read (interacts with) 3",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Mrs. Read (interacts with) 3",
        "interaction" : "interacts with",
        "SUID" : 7061,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "6999",
        "source" : "6961",
        "target" : "6967",
        "shared_name" : "Mrs. Read (interacts with) 2",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Mrs. Read (interacts with) 2",
        "interaction" : "interacts with",
        "SUID" : 6999,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "6964",
        "source" : "6961",
        "target" : "6913",
        "shared_name" : "Mrs. Read (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Mrs. Read (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 6964,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "6958",
        "source" : "6955",
        "target" : "6913",
        "shared_name" : "Kate (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Kate (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 6958,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7338",
        "source" : "6928",
        "target" : "7204",
        "shared_name" : "Buster (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Buster (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 7338,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7332",
        "source" : "6928",
        "target" : "7204",
        "shared_name" : "Buster (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Buster (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 7332,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7323",
        "source" : "6928",
        "target" : "7204",
        "shared_name" : "Buster (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Buster (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 7323,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7317",
        "source" : "6928",
        "target" : "7204",
        "shared_name" : "Buster (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Buster (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 7317,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7311",
        "source" : "6928",
        "target" : "7204",
        "shared_name" : "Buster (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Buster (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 7311,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7302",
        "source" : "6928",
        "target" : "7204",
        "shared_name" : "Buster (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Buster (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 7302,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7299",
        "source" : "6928",
        "target" : "7204",
        "shared_name" : "Buster (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Buster (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 7299,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7296",
        "source" : "6928",
        "target" : "7204",
        "shared_name" : "Buster (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Buster (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 7296,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7290",
        "source" : "6928",
        "target" : "7204",
        "shared_name" : "Buster (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Buster (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 7290,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7287",
        "source" : "6928",
        "target" : "7204",
        "shared_name" : "Buster (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Buster (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 7287,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7281",
        "source" : "6928",
        "target" : "7204",
        "shared_name" : "Buster (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Buster (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 7281,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7275",
        "source" : "6928",
        "target" : "7204",
        "shared_name" : "Buster (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Buster (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 7275,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7269",
        "source" : "6928",
        "target" : "7204",
        "shared_name" : "Buster (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Buster (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 7269,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7263",
        "source" : "6928",
        "target" : "7204",
        "shared_name" : "Buster (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Buster (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 7263,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7257",
        "source" : "6928",
        "target" : "7204",
        "shared_name" : "Buster (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Buster (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 7257,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7251",
        "source" : "6928",
        "target" : "7204",
        "shared_name" : "Buster (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Buster (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 7251,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7242",
        "source" : "6928",
        "target" : "7204",
        "shared_name" : "Buster (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Buster (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 7242,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7227",
        "source" : "6928",
        "target" : "7204",
        "shared_name" : "Buster (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Buster (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 7227,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7218",
        "source" : "6928",
        "target" : "7204",
        "shared_name" : "Buster (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Buster (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 7218,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7147",
        "source" : "6928",
        "target" : "7097",
        "shared_name" : "Buster (interacts with) 4",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Buster (interacts with) 4",
        "interaction" : "interacts with",
        "SUID" : 7147,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7135",
        "source" : "6928",
        "target" : "7097",
        "shared_name" : "Buster (interacts with) 4",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Buster (interacts with) 4",
        "interaction" : "interacts with",
        "SUID" : 7135,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7114",
        "source" : "6928",
        "target" : "7097",
        "shared_name" : "Buster (interacts with) 4",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Buster (interacts with) 4",
        "interaction" : "interacts with",
        "SUID" : 7114,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7111",
        "source" : "6928",
        "target" : "7097",
        "shared_name" : "Buster (interacts with) 4",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Buster (interacts with) 4",
        "interaction" : "interacts with",
        "SUID" : 7111,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7099",
        "source" : "6928",
        "target" : "7097",
        "shared_name" : "Buster (interacts with) 4",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Buster (interacts with) 4",
        "interaction" : "interacts with",
        "SUID" : 7099,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "6949",
        "source" : "6928",
        "target" : "6913",
        "shared_name" : "Buster (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Buster (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 6949,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "6943",
        "source" : "6928",
        "target" : "6913",
        "shared_name" : "Buster (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Buster (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 6943,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "6937",
        "source" : "6928",
        "target" : "6913",
        "shared_name" : "Buster (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Buster (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 6937,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "6931",
        "source" : "6928",
        "target" : "6913",
        "shared_name" : "Buster (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Buster (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 6931,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7341",
        "source" : "6911",
        "target" : "7204",
        "shared_name" : "Arthur (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 7341,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7335",
        "source" : "6911",
        "target" : "7204",
        "shared_name" : "Arthur (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 7335,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7326",
        "source" : "6911",
        "target" : "7204",
        "shared_name" : "Arthur (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 7326,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7320",
        "source" : "6911",
        "target" : "7204",
        "shared_name" : "Arthur (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 7320,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7305",
        "source" : "6911",
        "target" : "7204",
        "shared_name" : "Arthur (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 7305,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7293",
        "source" : "6911",
        "target" : "7204",
        "shared_name" : "Arthur (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 7293,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7284",
        "source" : "6911",
        "target" : "7204",
        "shared_name" : "Arthur (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 7284,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7278",
        "source" : "6911",
        "target" : "7204",
        "shared_name" : "Arthur (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 7278,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7272",
        "source" : "6911",
        "target" : "7204",
        "shared_name" : "Arthur (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 7272,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7266",
        "source" : "6911",
        "target" : "7204",
        "shared_name" : "Arthur (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 7266,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7260",
        "source" : "6911",
        "target" : "7204",
        "shared_name" : "Arthur (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 7260,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7248",
        "source" : "6911",
        "target" : "7204",
        "shared_name" : "Arthur (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 7248,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7239",
        "source" : "6911",
        "target" : "7204",
        "shared_name" : "Arthur (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 7239,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7233",
        "source" : "6911",
        "target" : "7204",
        "shared_name" : "Arthur (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 7233,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7221",
        "source" : "6911",
        "target" : "7204",
        "shared_name" : "Arthur (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 7221,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7215",
        "source" : "6911",
        "target" : "7204",
        "shared_name" : "Arthur (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 7215,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7212",
        "source" : "6911",
        "target" : "7204",
        "shared_name" : "Arthur (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 7212,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7209",
        "source" : "6911",
        "target" : "7204",
        "shared_name" : "Arthur (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 7209,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7189",
        "source" : "6911",
        "target" : "7097",
        "shared_name" : "Arthur (interacts with) 4",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 4",
        "interaction" : "interacts with",
        "SUID" : 7189,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7183",
        "source" : "6911",
        "target" : "7097",
        "shared_name" : "Arthur (interacts with) 4",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 4",
        "interaction" : "interacts with",
        "SUID" : 7183,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7180",
        "source" : "6911",
        "target" : "7097",
        "shared_name" : "Arthur (interacts with) 4",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 4",
        "interaction" : "interacts with",
        "SUID" : 7180,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7174",
        "source" : "6911",
        "target" : "7097",
        "shared_name" : "Arthur (interacts with) 4",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 4",
        "interaction" : "interacts with",
        "SUID" : 7174,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7171",
        "source" : "6911",
        "target" : "7097",
        "shared_name" : "Arthur (interacts with) 4",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 4",
        "interaction" : "interacts with",
        "SUID" : 7171,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7168",
        "source" : "6911",
        "target" : "7097",
        "shared_name" : "Arthur (interacts with) 4",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 4",
        "interaction" : "interacts with",
        "SUID" : 7168,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7165",
        "source" : "6911",
        "target" : "7097",
        "shared_name" : "Arthur (interacts with) 4",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 4",
        "interaction" : "interacts with",
        "SUID" : 7165,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7162",
        "source" : "6911",
        "target" : "7097",
        "shared_name" : "Arthur (interacts with) 4",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 4",
        "interaction" : "interacts with",
        "SUID" : 7162,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7159",
        "source" : "6911",
        "target" : "7097",
        "shared_name" : "Arthur (interacts with) 4",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 4",
        "interaction" : "interacts with",
        "SUID" : 7159,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7156",
        "source" : "6911",
        "target" : "7097",
        "shared_name" : "Arthur (interacts with) 4",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 4",
        "interaction" : "interacts with",
        "SUID" : 7156,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7150",
        "source" : "6911",
        "target" : "7097",
        "shared_name" : "Arthur (interacts with) 4",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 4",
        "interaction" : "interacts with",
        "SUID" : 7150,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7144",
        "source" : "6911",
        "target" : "7097",
        "shared_name" : "Arthur (interacts with) 4",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 4",
        "interaction" : "interacts with",
        "SUID" : 7144,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7141",
        "source" : "6911",
        "target" : "7097",
        "shared_name" : "Arthur (interacts with) 4",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 4",
        "interaction" : "interacts with",
        "SUID" : 7141,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7138",
        "source" : "6911",
        "target" : "7097",
        "shared_name" : "Arthur (interacts with) 4",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 4",
        "interaction" : "interacts with",
        "SUID" : 7138,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7132",
        "source" : "6911",
        "target" : "7097",
        "shared_name" : "Arthur (interacts with) 4",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 4",
        "interaction" : "interacts with",
        "SUID" : 7132,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7126",
        "source" : "6911",
        "target" : "7097",
        "shared_name" : "Arthur (interacts with) 4",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 4",
        "interaction" : "interacts with",
        "SUID" : 7126,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7117",
        "source" : "6911",
        "target" : "7097",
        "shared_name" : "Arthur (interacts with) 4",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 4",
        "interaction" : "interacts with",
        "SUID" : 7117,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7108",
        "source" : "6911",
        "target" : "7097",
        "shared_name" : "Arthur (interacts with) 4",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 4",
        "interaction" : "interacts with",
        "SUID" : 7108,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7091",
        "source" : "6911",
        "target" : "7040",
        "shared_name" : "Arthur (interacts with) 3",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 3",
        "interaction" : "interacts with",
        "SUID" : 7091,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7082",
        "source" : "6911",
        "target" : "7040",
        "shared_name" : "Arthur (interacts with) 3",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 3",
        "interaction" : "interacts with",
        "SUID" : 7082,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7076",
        "source" : "6911",
        "target" : "7040",
        "shared_name" : "Arthur (interacts with) 3",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 3",
        "interaction" : "interacts with",
        "SUID" : 7076,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7070",
        "source" : "6911",
        "target" : "7040",
        "shared_name" : "Arthur (interacts with) 3",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 3",
        "interaction" : "interacts with",
        "SUID" : 7070,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7064",
        "source" : "6911",
        "target" : "7040",
        "shared_name" : "Arthur (interacts with) 3",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 3",
        "interaction" : "interacts with",
        "SUID" : 7064,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7058",
        "source" : "6911",
        "target" : "7040",
        "shared_name" : "Arthur (interacts with) 3",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 3",
        "interaction" : "interacts with",
        "SUID" : 7058,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7055",
        "source" : "6911",
        "target" : "7040",
        "shared_name" : "Arthur (interacts with) 3",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 3",
        "interaction" : "interacts with",
        "SUID" : 7055,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7046",
        "source" : "6911",
        "target" : "7040",
        "shared_name" : "Arthur (interacts with) 3",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 3",
        "interaction" : "interacts with",
        "SUID" : 7046,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7020",
        "source" : "6911",
        "target" : "6967",
        "shared_name" : "Arthur (interacts with) 2",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 2",
        "interaction" : "interacts with",
        "SUID" : 7020,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7017",
        "source" : "6911",
        "target" : "6967",
        "shared_name" : "Arthur (interacts with) 2",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 2",
        "interaction" : "interacts with",
        "SUID" : 7017,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7014",
        "source" : "6911",
        "target" : "6967",
        "shared_name" : "Arthur (interacts with) 2",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 2",
        "interaction" : "interacts with",
        "SUID" : 7014,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7002",
        "source" : "6911",
        "target" : "6967",
        "shared_name" : "Arthur (interacts with) 2",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 2",
        "interaction" : "interacts with",
        "SUID" : 7002,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "6996",
        "source" : "6911",
        "target" : "6967",
        "shared_name" : "Arthur (interacts with) 2",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 2",
        "interaction" : "interacts with",
        "SUID" : 6996,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "6993",
        "source" : "6911",
        "target" : "6967",
        "shared_name" : "Arthur (interacts with) 2",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 2",
        "interaction" : "interacts with",
        "SUID" : 6993,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "6987",
        "source" : "6911",
        "target" : "6967",
        "shared_name" : "Arthur (interacts with) 2",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 2",
        "interaction" : "interacts with",
        "SUID" : 6987,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "6978",
        "source" : "6911",
        "target" : "6967",
        "shared_name" : "Arthur (interacts with) 2",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 2",
        "interaction" : "interacts with",
        "SUID" : 6978,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "6969",
        "source" : "6911",
        "target" : "6967",
        "shared_name" : "Arthur (interacts with) 2",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 2",
        "interaction" : "interacts with",
        "SUID" : 6969,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "6952",
        "source" : "6911",
        "target" : "6913",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 6952,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "6946",
        "source" : "6911",
        "target" : "6913",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 6946,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "6940",
        "source" : "6911",
        "target" : "6913",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 6940,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "6934",
        "source" : "6911",
        "target" : "6913",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 6934,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "6921",
        "source" : "6911",
        "target" : "6913",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 6921,
        "selected" : false
      },
      "selected" : false
    } ]
  }
}}