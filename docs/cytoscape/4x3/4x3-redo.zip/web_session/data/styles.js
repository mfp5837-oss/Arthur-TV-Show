var styles = [ {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "Nested Network Style",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "color" : "rgb(0,0,0)",
      "border-width" : 2.0,
      "text-opacity" : 1.0,
      "width" : 60.0,
      "shape" : "ellipse",
      "font-size" : 12,
      "text-valign" : "center",
      "text-halign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "background-opacity" : 1.0,
      "height" : 40.0,
      "background-color" : "rgb(255,255,255)",
      "border-opacity" : 1.0,
      "border-color" : "rgb(0,0,0)",
      "content" : "data(shared_name)"
    }
  }, {
    "selector" : "node[has_nested_network]",
    "css" : {
      "shape" : "rectangle"
    }
  }, {
    "selector" : "node[has_nested_network]",
    "css" : {
      "color" : "rgb(0,102,204)"
    }
  }, {
    "selector" : "node[has_nested_network]",
    "css" : {
      "border-color" : "rgb(0,102,204)"
    }
  }, {
    "selector" : "node[has_nested_network]",
    "css" : {
      "background-color" : "rgb(255,255,255)"
    }
  }, {
    "selector" : "node[has_nested_network]",
    "css" : {
      "text-valign" : "bottom"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "line-style" : "solid",
      "source-arrow-shape" : "none",
      "target-arrow-shape" : "none",
      "opacity" : 1.0,
      "source-arrow-color" : "rgb(0,0,0)",
      "line-color" : "rgb(64,64,64)",
      "content" : "",
      "width" : 1.0,
      "target-arrow-color" : "rgb(0,0,0)",
      "font-size" : 10,
      "text-opacity" : 1.0,
      "color" : "rgb(0,0,0)",
      "font-family" : "SansSerif",
      "font-weight" : "normal"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "Gradient1",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "color" : "rgb(204,204,204)",
      "border-width" : 0.0,
      "text-opacity" : 1.0,
      "width" : 30.0,
      "shape" : "ellipse",
      "font-size" : 8,
      "text-valign" : "bottom",
      "text-halign" : "right",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "background-opacity" : 1.0,
      "height" : 30.0,
      "background-color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "border-color" : "rgb(0,0,0)",
      "content" : "data(name)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "line-style" : "solid",
      "source-arrow-shape" : "none",
      "target-arrow-shape" : "none",
      "opacity" : 1.0,
      "source-arrow-color" : "rgb(0,0,0)",
      "line-color" : "rgb(102,102,102)",
      "content" : "",
      "width" : 1.0,
      "target-arrow-color" : "rgb(0,0,0)",
      "font-size" : 10,
      "text-opacity" : 1.0,
      "color" : "rgb(0,0,0)",
      "font-family" : "SansSerif",
      "font-weight" : "normal"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "Universe",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "color" : "rgb(255,255,255)",
      "border-width" : 0.0,
      "text-opacity" : 1.0,
      "width" : 40.0,
      "shape" : "ellipse",
      "font-size" : 18,
      "text-valign" : "center",
      "text-halign" : "center",
      "font-family" : "Monospaced",
      "font-weight" : "normal",
      "background-opacity" : 1.0,
      "height" : 40.0,
      "background-color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "border-color" : "rgb(0,0,0)",
      "content" : "data(name)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "line-style" : "dashed",
      "source-arrow-shape" : "none",
      "target-arrow-shape" : "none",
      "opacity" : 1.0,
      "source-arrow-color" : "rgb(0,0,0)",
      "line-color" : "rgb(153,153,153)",
      "content" : "",
      "width" : 2.0,
      "target-arrow-color" : "rgb(0,0,0)",
      "font-size" : 10,
      "text-opacity" : 1.0,
      "color" : "rgb(0,0,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "Big Labels",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "color" : "rgb(51,51,51)",
      "border-width" : 0.0,
      "text-opacity" : 1.0,
      "width" : 5.0,
      "shape" : "ellipse",
      "font-size" : 24,
      "text-valign" : "center",
      "text-halign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "background-opacity" : 1.0,
      "height" : 5.0,
      "background-color" : "rgb(255,255,255)",
      "border-opacity" : 1.0,
      "border-color" : "rgb(0,0,0)",
      "content" : "data(name)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,0,102)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "line-style" : "solid",
      "source-arrow-shape" : "none",
      "target-arrow-shape" : "none",
      "opacity" : 1.0,
      "source-arrow-color" : "rgb(0,0,0)",
      "line-color" : "rgb(183,183,183)",
      "content" : "",
      "width" : 1.0,
      "target-arrow-color" : "rgb(0,0,0)",
      "font-size" : 10,
      "text-opacity" : 1.0,
      "color" : "rgb(0,0,0)",
      "font-family" : "SansSerif",
      "font-weight" : "normal"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "Sample2",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "color" : "rgb(102,102,102)",
      "border-width" : 15.0,
      "text-opacity" : 1.0,
      "width" : 50.0,
      "shape" : "ellipse",
      "font-size" : 20,
      "text-valign" : "center",
      "text-halign" : "right",
      "font-family" : "HelveticaNeue-Light",
      "font-weight" : "normal",
      "background-opacity" : 1.0,
      "height" : 50.0,
      "background-color" : "rgb(58,127,182)",
      "border-opacity" : 1.0,
      "border-color" : "rgb(255,255,255)",
      "content" : "data(name)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "line-style" : "solid",
      "source-arrow-shape" : "none",
      "target-arrow-shape" : "none",
      "opacity" : 1.0,
      "source-arrow-color" : "rgb(0,0,0)",
      "line-color" : "rgb(255,255,255)",
      "content" : "",
      "width" : 20.0,
      "target-arrow-color" : "rgb(0,0,0)",
      "font-size" : 10,
      "text-opacity" : 1.0,
      "color" : "rgb(0,0,0)",
      "font-family" : "SansSerif",
      "font-weight" : "normal"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "Marquee",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "color" : "rgb(102,102,102)",
      "border-width" : 10.0,
      "text-opacity" : 1.0,
      "width" : 20.0,
      "shape" : "ellipse",
      "font-size" : 12,
      "text-valign" : "bottom",
      "text-halign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "background-opacity" : 1.0,
      "height" : 20.0,
      "background-color" : "rgb(0,204,255)",
      "border-opacity" : 1.0,
      "border-color" : "rgb(255,255,255)",
      "content" : "data(name)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,0,102)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "line-style" : "dashed",
      "source-arrow-shape" : "none",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "source-arrow-color" : "rgb(255,255,255)",
      "line-color" : "rgb(255,255,255)",
      "width" : 2.0,
      "target-arrow-color" : "rgb(255,255,255)",
      "font-size" : 8,
      "text-opacity" : 1.0,
      "color" : "rgb(102,102,102)",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "content" : "data(interaction)"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "Sample3",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "color" : "rgb(206,206,206)",
      "border-width" : 8.0,
      "text-opacity" : 1.0,
      "width" : 20.0,
      "shape" : "ellipse",
      "font-size" : 14,
      "text-valign" : "bottom",
      "text-halign" : "right",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "background-opacity" : 1.0,
      "height" : 20.0,
      "background-color" : "rgb(61,154,255)",
      "border-opacity" : 1.0,
      "border-color" : "rgb(255,255,255)",
      "content" : "data(name)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "line-style" : "solid",
      "source-arrow-shape" : "none",
      "target-arrow-shape" : "none",
      "opacity" : 1.0,
      "source-arrow-color" : "rgb(0,0,0)",
      "line-color" : "rgb(255,255,255)",
      "content" : "",
      "width" : 2.0,
      "target-arrow-color" : "rgb(0,0,0)",
      "font-size" : 10,
      "text-opacity" : 1.0,
      "color" : "rgb(0,0,0)",
      "font-family" : "SansSerif",
      "font-weight" : "normal"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "Sample1",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "color" : "rgb(51,51,51)",
      "border-width" : 0.0,
      "text-opacity" : 1.0,
      "width" : 25.0,
      "shape" : "ellipse",
      "font-size" : 10,
      "text-valign" : "center",
      "text-halign" : "center",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "background-opacity" : 1.0,
      "height" : 25.0,
      "background-color" : "rgb(127,205,187)",
      "border-opacity" : 1.0,
      "border-color" : "rgb(0,0,0)",
      "content" : "data(name)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "line-style" : "solid",
      "source-arrow-shape" : "none",
      "target-arrow-shape" : "none",
      "opacity" : 1.0,
      "source-arrow-color" : "rgb(0,0,0)",
      "line-color" : "rgb(153,153,153)",
      "width" : 1.0,
      "target-arrow-color" : "rgb(0,0,0)",
      "font-size" : 10,
      "text-opacity" : 1.0,
      "color" : "rgb(51,51,51)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "content" : "data(interaction)"
    }
  }, {
    "selector" : "edge[interaction = 'pp']",
    "css" : {
      "line-style" : "solid"
    }
  }, {
    "selector" : "edge[interaction = 'pd']",
    "css" : {
      "line-style" : "dashed"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "Solid",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "color" : "rgb(0,0,0)",
      "border-width" : 0.0,
      "text-opacity" : 1.0,
      "width" : 40.0,
      "shape" : "ellipse",
      "font-size" : 14,
      "text-valign" : "center",
      "text-halign" : "center",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "background-opacity" : 1.0,
      "height" : 40.0,
      "background-color" : "rgb(102,102,102)",
      "border-opacity" : 1.0,
      "border-color" : "rgb(0,0,0)",
      "content" : "data(name)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "line-style" : "solid",
      "source-arrow-shape" : "none",
      "target-arrow-shape" : "none",
      "opacity" : 1.0,
      "source-arrow-color" : "rgb(0,0,0)",
      "line-color" : "rgb(204,204,204)",
      "width" : 12.0,
      "target-arrow-color" : "rgb(0,0,0)",
      "font-size" : 10,
      "text-opacity" : 1.0,
      "color" : "rgb(0,0,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "content" : "data(interaction)"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "default",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "color" : "rgb(0,0,0)",
      "border-width" : 0.0,
      "text-opacity" : 1.0,
      "width" : 75.0,
      "shape" : "roundrectangle",
      "font-size" : 12,
      "text-valign" : "center",
      "text-halign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "background-opacity" : 1.0,
      "height" : 35.0,
      "background-color" : "rgb(137,208,245)",
      "border-opacity" : 1.0,
      "border-color" : "rgb(204,204,204)",
      "content" : "data(name)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "line-style" : "solid",
      "source-arrow-shape" : "none",
      "target-arrow-shape" : "none",
      "opacity" : 1.0,
      "source-arrow-color" : "rgb(0,0,0)",
      "line-color" : "rgb(132,132,132)",
      "content" : "",
      "width" : 2.0,
      "target-arrow-color" : "rgb(0,0,0)",
      "font-size" : 10,
      "text-opacity" : 1.0,
      "color" : "rgb(0,0,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "Ripple",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "color" : "rgb(19,58,96)",
      "border-width" : 20.0,
      "text-opacity" : 1.0,
      "width" : 50.0,
      "shape" : "ellipse",
      "font-size" : 8,
      "text-valign" : "center",
      "text-halign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "background-opacity" : 1.0,
      "height" : 50.0,
      "background-color" : "rgb(255,255,255)",
      "border-opacity" : 1.0,
      "border-color" : "rgb(51,153,255)",
      "content" : "data(name)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,204)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "line-style" : "solid",
      "source-arrow-shape" : "none",
      "target-arrow-shape" : "none",
      "opacity" : 1.0,
      "source-arrow-color" : "rgb(0,0,0)",
      "line-color" : "rgb(51,153,255)",
      "content" : "",
      "width" : 3.0,
      "target-arrow-color" : "rgb(0,0,0)",
      "font-size" : 10,
      "text-opacity" : 1.0,
      "color" : "rgb(0,0,0)",
      "font-family" : "SansSerif",
      "font-weight" : "normal"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "default black",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "color" : "rgb(204,204,204)",
      "border-width" : 0.0,
      "text-opacity" : 1.0,
      "width" : 15.0,
      "shape" : "ellipse",
      "font-size" : 12,
      "text-valign" : "bottom",
      "text-halign" : "right",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "background-opacity" : 1.0,
      "height" : 15.0,
      "background-color" : "rgb(255,255,255)",
      "border-opacity" : 1.0,
      "border-color" : "rgb(0,153,0)",
      "content" : "data(name)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "line-style" : "solid",
      "source-arrow-shape" : "none",
      "target-arrow-shape" : "none",
      "opacity" : 1.0,
      "source-arrow-color" : "rgb(0,0,0)",
      "line-color" : "rgb(0,153,0)",
      "content" : "",
      "width" : 2.0,
      "target-arrow-color" : "rgb(0,0,0)",
      "font-size" : 10,
      "text-opacity" : 1.0,
      "color" : "rgb(0,0,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "Curved",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "color" : "rgb(102,102,102)",
      "border-width" : 7.0,
      "text-opacity" : 1.0,
      "width" : 18.0,
      "shape" : "ellipse",
      "font-size" : 14,
      "text-valign" : "bottom",
      "text-halign" : "right",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "background-opacity" : 1.0,
      "height" : 18.0,
      "background-color" : "rgb(254,196,79)",
      "border-opacity" : 1.0,
      "border-color" : "rgb(255,255,255)",
      "content" : "data(name)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "line-style" : "solid",
      "source-arrow-shape" : "none",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "source-arrow-color" : "rgb(255,255,255)",
      "line-color" : "rgb(255,255,255)",
      "content" : "",
      "width" : 3.0,
      "target-arrow-color" : "rgb(255,255,255)",
      "font-size" : 10,
      "text-opacity" : 1.0,
      "color" : "rgb(0,0,0)",
      "font-family" : "SansSerif",
      "font-weight" : "normal"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "Minimal",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "color" : "rgb(51,51,51)",
      "border-width" : 0.0,
      "text-opacity" : 1.0,
      "width" : 42.0,
      "shape" : "rectangle",
      "font-size" : 9,
      "text-valign" : "center",
      "text-halign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "background-opacity" : 1.0,
      "height" : 42.0,
      "background-color" : "rgb(255,255,255)",
      "border-opacity" : 1.0,
      "border-color" : "rgb(0,0,0)",
      "content" : "data(name)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "line-style" : "solid",
      "source-arrow-shape" : "none",
      "target-arrow-shape" : "none",
      "opacity" : 1.0,
      "source-arrow-color" : "rgb(0,0,0)",
      "line-color" : "rgb(76,76,76)",
      "content" : "",
      "width" : 2.0,
      "target-arrow-color" : "rgb(0,0,0)",
      "font-size" : 10,
      "text-opacity" : 1.0,
      "color" : "rgb(0,0,0)",
      "font-family" : "SansSerif",
      "font-weight" : "normal"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "Directed",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "color" : "rgb(51,153,255)",
      "border-width" : 5.0,
      "text-opacity" : 1.0,
      "width" : 45.0,
      "shape" : "ellipse",
      "font-size" : 8,
      "text-valign" : "center",
      "text-halign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "background-opacity" : 1.0,
      "height" : 45.0,
      "background-color" : "rgb(255,255,255)",
      "border-opacity" : 1.0,
      "border-color" : "rgb(145,145,145)",
      "content" : "data(name)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,0,102)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "line-style" : "solid",
      "source-arrow-shape" : "none",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "source-arrow-color" : "rgb(204,204,204)",
      "line-color" : "rgb(204,204,204)",
      "width" : 5.0,
      "target-arrow-color" : "rgb(204,204,204)",
      "font-size" : 12,
      "text-opacity" : 1.0,
      "color" : "rgb(51,153,255)",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "content" : "data(interaction)"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
} ]