var styles = [ {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "Minimal",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "border-opacity" : 1.0,
      "width" : 42.0,
      "background-color" : "rgb(255,255,255)",
      "color" : "rgb(51,51,51)",
      "border-width" : 0.0,
      "border-color" : "rgb(0,0,0)",
      "background-opacity" : 1.0,
      "text-opacity" : 1.0,
      "shape" : "rectangle",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "height" : 42.0,
      "text-valign" : "center",
      "text-halign" : "center",
      "font-size" : 9,
      "content" : "data(name)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "content" : "",
      "line-style" : "solid",
      "target-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "opacity" : 1.0,
      "color" : "rgb(0,0,0)",
      "text-opacity" : 1.0,
      "font-size" : 10,
      "source-arrow-shape" : "none",
      "width" : 2.0,
      "target-arrow-color" : "rgb(0,0,0)",
      "line-color" : "rgb(76,76,76)"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "Sample2",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "border-opacity" : 1.0,
      "width" : 50.0,
      "background-color" : "rgb(58,127,182)",
      "color" : "rgb(102,102,102)",
      "border-width" : 15.0,
      "border-color" : "rgb(255,255,255)",
      "background-opacity" : 1.0,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "font-family" : "HelveticaNeue-Light",
      "font-weight" : "normal",
      "height" : 50.0,
      "text-valign" : "center",
      "text-halign" : "right",
      "font-size" : 20,
      "content" : "data(name)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "content" : "",
      "line-style" : "solid",
      "target-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "opacity" : 1.0,
      "color" : "rgb(0,0,0)",
      "text-opacity" : 1.0,
      "font-size" : 10,
      "source-arrow-shape" : "none",
      "width" : 20.0,
      "target-arrow-color" : "rgb(0,0,0)",
      "line-color" : "rgb(255,255,255)"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "Directed",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "border-opacity" : 1.0,
      "width" : 45.0,
      "background-color" : "rgb(255,255,255)",
      "color" : "rgb(51,153,255)",
      "border-width" : 5.0,
      "border-color" : "rgb(145,145,145)",
      "background-opacity" : 1.0,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "height" : 45.0,
      "text-valign" : "center",
      "text-halign" : "center",
      "font-size" : 8,
      "content" : "data(name)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,0,102)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "line-style" : "solid",
      "target-arrow-shape" : "triangle",
      "source-arrow-color" : "rgb(204,204,204)",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "opacity" : 1.0,
      "color" : "rgb(51,153,255)",
      "text-opacity" : 1.0,
      "font-size" : 12,
      "source-arrow-shape" : "none",
      "width" : 5.0,
      "target-arrow-color" : "rgb(204,204,204)",
      "line-color" : "rgb(204,204,204)",
      "content" : "data(interaction)"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "Gradient1",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "border-opacity" : 1.0,
      "width" : 30.0,
      "background-color" : "rgb(0,0,0)",
      "color" : "rgb(204,204,204)",
      "border-width" : 0.0,
      "border-color" : "rgb(0,0,0)",
      "background-opacity" : 1.0,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "height" : 30.0,
      "text-valign" : "bottom",
      "text-halign" : "right",
      "font-size" : 8,
      "content" : "data(name)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "content" : "",
      "line-style" : "solid",
      "target-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "opacity" : 1.0,
      "color" : "rgb(0,0,0)",
      "text-opacity" : 1.0,
      "font-size" : 10,
      "source-arrow-shape" : "none",
      "width" : 1.0,
      "target-arrow-color" : "rgb(0,0,0)",
      "line-color" : "rgb(102,102,102)"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "Big Labels",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "border-opacity" : 1.0,
      "width" : 5.0,
      "background-color" : "rgb(255,255,255)",
      "color" : "rgb(51,51,51)",
      "border-width" : 0.0,
      "border-color" : "rgb(0,0,0)",
      "background-opacity" : 1.0,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "height" : 5.0,
      "text-valign" : "center",
      "text-halign" : "center",
      "font-size" : 24,
      "content" : "data(name)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,0,102)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "content" : "",
      "line-style" : "solid",
      "target-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "opacity" : 1.0,
      "color" : "rgb(0,0,0)",
      "text-opacity" : 1.0,
      "font-size" : 10,
      "source-arrow-shape" : "none",
      "width" : 1.0,
      "target-arrow-color" : "rgb(0,0,0)",
      "line-color" : "rgb(183,183,183)"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "Nested Network Style",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "border-opacity" : 1.0,
      "width" : 60.0,
      "background-color" : "rgb(255,255,255)",
      "color" : "rgb(0,0,0)",
      "border-width" : 2.0,
      "border-color" : "rgb(0,0,0)",
      "background-opacity" : 1.0,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "height" : 40.0,
      "text-valign" : "center",
      "text-halign" : "center",
      "font-size" : 12,
      "content" : "data(shared_name)"
    }
  }, {
    "selector" : "node[has_nested_network]",
    "css" : {
      "background-color" : "rgb(255,255,255)"
    }
  }, {
    "selector" : "node[has_nested_network]",
    "css" : {
      "color" : "rgb(0,102,204)"
    }
  }, {
    "selector" : "node[has_nested_network]",
    "css" : {
      "text-valign" : "bottom"
    }
  }, {
    "selector" : "node[has_nested_network]",
    "css" : {
      "border-color" : "rgb(0,102,204)"
    }
  }, {
    "selector" : "node[has_nested_network]",
    "css" : {
      "shape" : "rectangle"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "content" : "",
      "line-style" : "solid",
      "target-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "opacity" : 1.0,
      "color" : "rgb(0,0,0)",
      "text-opacity" : 1.0,
      "font-size" : 10,
      "source-arrow-shape" : "none",
      "width" : 1.0,
      "target-arrow-color" : "rgb(0,0,0)",
      "line-color" : "rgb(64,64,64)"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "size_rank",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "border-opacity" : 1.0,
      "width" : 12.0,
      "background-color" : "rgb(204,204,255)",
      "color" : "rgb(51,51,51)",
      "border-width" : 0.0,
      "border-color" : "rgb(0,0,0)",
      "background-opacity" : 1.0,
      "text-opacity" : 1.0,
      "shape" : "rectangle",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "height" : 12.0,
      "text-valign" : "center",
      "text-halign" : "center",
      "font-size" : 9,
      "content" : "data(name)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "content" : "",
      "line-style" : "solid",
      "target-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "opacity" : 1.0,
      "color" : "rgb(0,0,0)",
      "text-opacity" : 1.0,
      "font-size" : 10,
      "source-arrow-shape" : "none",
      "width" : 2.0,
      "target-arrow-color" : "rgb(0,0,0)",
      "line-color" : "rgb(76,76,76)"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "Curved",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "border-opacity" : 1.0,
      "width" : 18.0,
      "background-color" : "rgb(254,196,79)",
      "color" : "rgb(102,102,102)",
      "border-width" : 7.0,
      "border-color" : "rgb(255,255,255)",
      "background-opacity" : 1.0,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "height" : 18.0,
      "text-valign" : "bottom",
      "text-halign" : "right",
      "font-size" : 14,
      "content" : "data(name)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "content" : "",
      "line-style" : "solid",
      "target-arrow-shape" : "triangle",
      "source-arrow-color" : "rgb(255,255,255)",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "opacity" : 1.0,
      "color" : "rgb(0,0,0)",
      "text-opacity" : 1.0,
      "font-size" : 10,
      "source-arrow-shape" : "none",
      "width" : 3.0,
      "target-arrow-color" : "rgb(255,255,255)",
      "line-color" : "rgb(255,255,255)"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "Universe",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "border-opacity" : 1.0,
      "width" : 40.0,
      "background-color" : "rgb(0,0,0)",
      "color" : "rgb(255,255,255)",
      "border-width" : 0.0,
      "border-color" : "rgb(0,0,0)",
      "background-opacity" : 1.0,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "font-family" : "Monospaced",
      "font-weight" : "normal",
      "height" : 40.0,
      "text-valign" : "center",
      "text-halign" : "center",
      "font-size" : 18,
      "content" : "data(name)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "content" : "",
      "line-style" : "dashed",
      "target-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "opacity" : 1.0,
      "color" : "rgb(0,0,0)",
      "text-opacity" : 1.0,
      "font-size" : 10,
      "source-arrow-shape" : "none",
      "width" : 2.0,
      "target-arrow-color" : "rgb(0,0,0)",
      "line-color" : "rgb(153,153,153)"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "Ripple",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "border-opacity" : 1.0,
      "width" : 50.0,
      "background-color" : "rgb(255,255,255)",
      "color" : "rgb(19,58,96)",
      "border-width" : 20.0,
      "border-color" : "rgb(51,153,255)",
      "background-opacity" : 1.0,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "height" : 50.0,
      "text-valign" : "center",
      "text-halign" : "center",
      "font-size" : 8,
      "content" : "data(name)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,204)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "content" : "",
      "line-style" : "solid",
      "target-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "opacity" : 1.0,
      "color" : "rgb(0,0,0)",
      "text-opacity" : 1.0,
      "font-size" : 10,
      "source-arrow-shape" : "none",
      "width" : 3.0,
      "target-arrow-color" : "rgb(0,0,0)",
      "line-color" : "rgb(51,153,255)"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "default black",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "border-opacity" : 1.0,
      "width" : 15.0,
      "background-color" : "rgb(255,255,255)",
      "color" : "rgb(204,204,204)",
      "border-width" : 0.0,
      "border-color" : "rgb(0,153,0)",
      "background-opacity" : 1.0,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "height" : 15.0,
      "text-valign" : "bottom",
      "text-halign" : "right",
      "font-size" : 12,
      "content" : "data(name)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "content" : "",
      "line-style" : "solid",
      "target-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "opacity" : 1.0,
      "color" : "rgb(0,0,0)",
      "text-opacity" : 1.0,
      "font-size" : 10,
      "source-arrow-shape" : "none",
      "width" : 2.0,
      "target-arrow-color" : "rgb(0,0,0)",
      "line-color" : "rgb(0,153,0)"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "Marquee",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "border-opacity" : 1.0,
      "width" : 20.0,
      "background-color" : "rgb(0,204,255)",
      "color" : "rgb(102,102,102)",
      "border-width" : 10.0,
      "border-color" : "rgb(255,255,255)",
      "background-opacity" : 1.0,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "height" : 20.0,
      "text-valign" : "bottom",
      "text-halign" : "center",
      "font-size" : 12,
      "content" : "data(name)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,0,102)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "line-style" : "dashed",
      "target-arrow-shape" : "triangle",
      "source-arrow-color" : "rgb(255,255,255)",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "opacity" : 1.0,
      "color" : "rgb(102,102,102)",
      "text-opacity" : 1.0,
      "font-size" : 8,
      "source-arrow-shape" : "none",
      "width" : 2.0,
      "target-arrow-color" : "rgb(255,255,255)",
      "line-color" : "rgb(255,255,255)",
      "content" : "data(interaction)"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "Sample3",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "border-opacity" : 1.0,
      "width" : 20.0,
      "background-color" : "rgb(61,154,255)",
      "color" : "rgb(206,206,206)",
      "border-width" : 8.0,
      "border-color" : "rgb(255,255,255)",
      "background-opacity" : 1.0,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "height" : 20.0,
      "text-valign" : "bottom",
      "text-halign" : "right",
      "font-size" : 14,
      "content" : "data(name)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "content" : "",
      "line-style" : "solid",
      "target-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "opacity" : 1.0,
      "color" : "rgb(0,0,0)",
      "text-opacity" : 1.0,
      "font-size" : 10,
      "source-arrow-shape" : "none",
      "width" : 2.0,
      "target-arrow-color" : "rgb(0,0,0)",
      "line-color" : "rgb(255,255,255)"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "Solid",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "border-opacity" : 1.0,
      "width" : 40.0,
      "background-color" : "rgb(102,102,102)",
      "color" : "rgb(0,0,0)",
      "border-width" : 0.0,
      "border-color" : "rgb(0,0,0)",
      "background-opacity" : 1.0,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "height" : 40.0,
      "text-valign" : "center",
      "text-halign" : "center",
      "font-size" : 14,
      "content" : "data(name)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "line-style" : "solid",
      "target-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "opacity" : 1.0,
      "color" : "rgb(0,0,0)",
      "text-opacity" : 1.0,
      "font-size" : 10,
      "source-arrow-shape" : "none",
      "width" : 12.0,
      "target-arrow-color" : "rgb(0,0,0)",
      "line-color" : "rgb(204,204,204)",
      "content" : "data(interaction)"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "default",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "border-opacity" : 1.0,
      "width" : 75.0,
      "background-color" : "rgb(33,113,181)",
      "color" : "rgb(247,251,255)",
      "border-width" : 0.5,
      "border-color" : "rgb(204,204,204)",
      "background-opacity" : 1.0,
      "text-opacity" : 1.0,
      "shape" : "diamond",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "height" : 35.0,
      "text-valign" : "center",
      "text-halign" : "center",
      "font-size" : 12,
      "content" : "data(name)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "content" : "",
      "line-style" : "dashed",
      "target-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "opacity" : 1.0,
      "color" : "rgb(0,0,0)",
      "text-opacity" : 1.0,
      "font-size" : 10,
      "source-arrow-shape" : "none",
      "width" : 2.0,
      "target-arrow-color" : "rgb(0,0,0)",
      "line-color" : "rgb(37,37,37)"
    }
  }, {
    "selector" : "edge[countInScene > 2]",
    "css" : {
      "line-color" : "rgb(68,1,84)"
    }
  }, {
    "selector" : "edge[countInScene = 2]",
    "css" : {
      "line-color" : "rgb(68,2,86)"
    }
  }, {
    "selector" : "edge[countInScene > 1.31155014][countInScene < 2]",
    "css" : {
      "line-color" : "mapData(countInScene,1.31155014,2,rgb(255,255,255),rgb(68,2,86))"
    }
  }, {
    "selector" : "edge[countInScene > 1.15197569][countInScene < 1.31155014]",
    "css" : {
      "line-color" : "mapData(countInScene,1.15197569,1.31155014,rgb(251,231,35),rgb(255,255,255))"
    }
  }, {
    "selector" : "edge[countInScene > 1][countInScene < 1.15197569]",
    "css" : {
      "line-color" : "mapData(countInScene,1,1.15197569,rgb(33,145,140),rgb(251,231,35))"
    }
  }, {
    "selector" : "edge[countInScene = 1]",
    "css" : {
      "line-color" : "rgb(33,145,140)"
    }
  }, {
    "selector" : "edge[countInScene < 1]",
    "css" : {
      "line-color" : "rgb(253,231,37)"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "Sample1",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "border-opacity" : 1.0,
      "width" : 25.0,
      "background-color" : "rgb(127,205,187)",
      "color" : "rgb(51,51,51)",
      "border-width" : 0.0,
      "border-color" : "rgb(0,0,0)",
      "background-opacity" : 1.0,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "height" : 25.0,
      "text-valign" : "center",
      "text-halign" : "center",
      "font-size" : 10,
      "content" : "data(name)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "line-style" : "solid",
      "target-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "opacity" : 1.0,
      "color" : "rgb(51,51,51)",
      "text-opacity" : 1.0,
      "font-size" : 10,
      "source-arrow-shape" : "none",
      "width" : 1.0,
      "target-arrow-color" : "rgb(0,0,0)",
      "line-color" : "rgb(153,153,153)",
      "content" : "data(interaction)"
    }
  }, {
    "selector" : "edge[interaction = 'pp']",
    "css" : {
      "line-style" : "solid"
    }
  }, {
    "selector" : "edge[interaction = 'pd']",
    "css" : {
      "line-style" : "dashed"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
} ]