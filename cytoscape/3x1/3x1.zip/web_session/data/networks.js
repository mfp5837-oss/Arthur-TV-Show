var networks = {"3x1.tsv": {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "data" : {
    "shared_name" : "3x1.tsv",
    "name" : "3x1.tsv",
    "SUID" : 155,
    "__Annotations" : [ "edgeThickness=1.0|canvas=foreground|fillOpacity=100.0|color=-525313|rotation=0.0|type=org.cytoscape.view.presentation.annotations.BoundedTextAnnotation|fontStyle=1|uuid=d56a060c-65a4-4c94-a81c-1a94b1413bbe|shapeType=ROUNDEDRECTANGLE|edgeColor=-14839360|fontFamily=Serif|edgeOpacity=100.0|name=How many times a characters are mention in S3 E1|x=-708.5968308942511|width=464.92654969262327|y=-235.21632466354555|z=0|fontSize=18|text=How many times a characters are mention in S3 E1|height=52.394091052821956" ],
    "selected" : true
  },
  "elements" : {
    "nodes" : [ {
      "data" : {
        "id" : "210",
        "shared_name" : "Buster, Binky, Brain and Sue Ellen",
        "name" : "Buster, Binky, Brain and Sue Ellen",
        "SUID" : 210,
        "sceneMarker" : "scene",
        "selected" : false
      },
      "position" : {
        "x" : -270.30116805407084,
        "y" : 110.5679890080491
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "208",
        "shared_name" : "Arthur, Brain, and Sue Ellen",
        "name" : "Arthur, Brain, and Sue Ellen",
        "SUID" : 208,
        "sceneMarker" : "scene",
        "selected" : false
      },
      "position" : {
        "x" : 131.44372754057684,
        "y" : -199.84960478684044
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "206",
        "shared_name" : "Buster, Binky, Brain, and Sue Ellen",
        "name" : "Buster, Binky, Brain, and Sue Ellen",
        "SUID" : 206,
        "sceneMarker" : "scene",
        "selected" : false
      },
      "position" : {
        "x" : -123.03813201427732,
        "y" : -246.95430632772891
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "204",
        "shared_name" : "David",
        "name" : "David",
        "SUID" : 204,
        "sceneMarker" : "scene",
        "selected" : false
      },
      "position" : {
        "x" : -200.265910974649,
        "y" : -190.94065536720845
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "202",
        "shared_name" : "David Read",
        "name" : "David Read",
        "SUID" : 202,
        "sceneMarker" : "scene",
        "selected" : false
      },
      "position" : {
        "x" : 233.3829212326561,
        "y" : 7.740145944297922
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "200",
        "shared_name" : "D.W.",
        "name" : "D.W.",
        "SUID" : 200,
        "sceneMarker" : "scene",
        "selected" : false
      },
      "position" : {
        "x" : -417.5346900536675,
        "y" : 7.740145944297922
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "198",
        "shared_name" : "D.W. Read",
        "name" : "D.W. Read",
        "SUID" : 198,
        "sceneMarker" : "scene",
        "selected" : false
      },
      "position" : {
        "x" : -95.1509545184204,
        "y" : 261.5895322316019
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "196",
        "shared_name" : "Sue Ellen",
        "name" : "Sue Ellen",
        "SUID" : 196,
        "sceneMarker" : "scene",
        "selected" : false
      },
      "position" : {
        "x" : 23.519044192733475,
        "y" : -249.29644051264154
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "194",
        "shared_name" : "Buster",
        "name" : "Buster",
        "SUID" : 194,
        "sceneMarker" : "scene",
        "selected" : false
      },
      "position" : {
        "x" : -317.6248631985551,
        "y" : -111.14395082918911
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "192",
        "shared_name" : "Binky",
        "name" : "Binky",
        "SUID" : 192,
        "sceneMarker" : "scene",
        "selected" : false
      },
      "position" : {
        "x" : -200.26591097464888,
        "y" : 206.42094725580432
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "190",
        "shared_name" : "Jane",
        "name" : "Jane",
        "SUID" : 190,
        "sceneMarker" : "scene",
        "selected" : false
      },
      "position" : {
        "x" : 206.52308347765876,
        "y" : -107.89408754562427
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "188",
        "shared_name" : "Francine Frensky",
        "name" : "Francine Frensky",
        "SUID" : 188,
        "sceneMarker" : "scene",
        "selected" : false
      },
      "position" : {
        "x" : 131.44372754057684,
        "y" : 215.32989667543632
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "186",
        "shared_name" : "Brain",
        "name" : "Brain",
        "SUID" : 186,
        "sceneMarker" : "scene",
        "selected" : false
      },
      "position" : {
        "x" : 206.52308347765864,
        "y" : 123.37437943422015
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "184",
        "shared_name" : "1",
        "name" : "1",
        "SUID" : 184,
        "sceneMarker" : "",
        "selected" : false
      },
      "position" : {
        "x" : -39.09614245992907,
        "y" : -21.83716352100477
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "182",
        "shared_name" : "Arthur",
        "name" : "Arthur",
        "SUID" : 182,
        "sceneMarker" : "scene",
        "selected" : false
      },
      "position" : {
        "x" : 23.519044192733645,
        "y" : 264.7767324012374
      },
      "selected" : false
    } ],
    "edges" : [ {
      "data" : {
        "id" : "462",
        "source" : "210",
        "target" : "184",
        "shared_name" : "Buster, Binky, Brain and Sue Ellen (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Buster, Binky, Brain and Sue Ellen (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 462,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "460",
        "source" : "208",
        "target" : "184",
        "shared_name" : "Arthur, Brain, and Sue Ellen (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur, Brain, and Sue Ellen (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 460,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "458",
        "source" : "206",
        "target" : "184",
        "shared_name" : "Buster, Binky, Brain, and Sue Ellen (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Buster, Binky, Brain, and Sue Ellen (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 458,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "456",
        "source" : "204",
        "target" : "184",
        "shared_name" : "David (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "David (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 456,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "454",
        "source" : "204",
        "target" : "184",
        "shared_name" : "David (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "David (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 454,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "452",
        "source" : "204",
        "target" : "184",
        "shared_name" : "David (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "David (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 452,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "450",
        "source" : "204",
        "target" : "184",
        "shared_name" : "David (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "David (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 450,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "448",
        "source" : "204",
        "target" : "184",
        "shared_name" : "David (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "David (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 448,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "446",
        "source" : "204",
        "target" : "184",
        "shared_name" : "David (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "David (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 446,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "444",
        "source" : "204",
        "target" : "184",
        "shared_name" : "David (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "David (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 444,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "442",
        "source" : "202",
        "target" : "184",
        "shared_name" : "David Read (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "David Read (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 442,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "440",
        "source" : "200",
        "target" : "184",
        "shared_name" : "D.W. (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "D.W. (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 440,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "438",
        "source" : "200",
        "target" : "184",
        "shared_name" : "D.W. (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "D.W. (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 438,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "436",
        "source" : "200",
        "target" : "184",
        "shared_name" : "D.W. (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "D.W. (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 436,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "434",
        "source" : "200",
        "target" : "184",
        "shared_name" : "D.W. (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "D.W. (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 434,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "432",
        "source" : "200",
        "target" : "184",
        "shared_name" : "D.W. (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "D.W. (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 432,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "430",
        "source" : "198",
        "target" : "184",
        "shared_name" : "D.W. Read (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "D.W. Read (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 430,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "428",
        "source" : "196",
        "target" : "184",
        "shared_name" : "Sue Ellen (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Sue Ellen (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 428,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "426",
        "source" : "196",
        "target" : "184",
        "shared_name" : "Sue Ellen (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Sue Ellen (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 426,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "424",
        "source" : "196",
        "target" : "184",
        "shared_name" : "Sue Ellen (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Sue Ellen (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 424,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "422",
        "source" : "196",
        "target" : "184",
        "shared_name" : "Sue Ellen (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Sue Ellen (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 422,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "420",
        "source" : "196",
        "target" : "184",
        "shared_name" : "Sue Ellen (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Sue Ellen (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 420,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "418",
        "source" : "196",
        "target" : "184",
        "shared_name" : "Sue Ellen (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Sue Ellen (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 418,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "416",
        "source" : "196",
        "target" : "184",
        "shared_name" : "Sue Ellen (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Sue Ellen (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 416,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "414",
        "source" : "196",
        "target" : "184",
        "shared_name" : "Sue Ellen (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Sue Ellen (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 414,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "412",
        "source" : "196",
        "target" : "184",
        "shared_name" : "Sue Ellen (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Sue Ellen (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 412,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "410",
        "source" : "196",
        "target" : "184",
        "shared_name" : "Sue Ellen (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Sue Ellen (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 410,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "408",
        "source" : "196",
        "target" : "184",
        "shared_name" : "Sue Ellen (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Sue Ellen (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 408,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "406",
        "source" : "194",
        "target" : "184",
        "shared_name" : "Buster (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Buster (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 406,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "404",
        "source" : "194",
        "target" : "184",
        "shared_name" : "Buster (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Buster (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 404,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "402",
        "source" : "194",
        "target" : "184",
        "shared_name" : "Buster (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Buster (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 402,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "400",
        "source" : "194",
        "target" : "184",
        "shared_name" : "Buster (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Buster (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 400,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "398",
        "source" : "194",
        "target" : "184",
        "shared_name" : "Buster (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Buster (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 398,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "396",
        "source" : "194",
        "target" : "184",
        "shared_name" : "Buster (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Buster (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 396,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "394",
        "source" : "194",
        "target" : "184",
        "shared_name" : "Buster (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Buster (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 394,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "392",
        "source" : "194",
        "target" : "184",
        "shared_name" : "Buster (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Buster (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 392,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "390",
        "source" : "192",
        "target" : "184",
        "shared_name" : "Binky (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Binky (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 390,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "388",
        "source" : "192",
        "target" : "184",
        "shared_name" : "Binky (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Binky (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 388,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "386",
        "source" : "192",
        "target" : "184",
        "shared_name" : "Binky (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Binky (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 386,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "384",
        "source" : "192",
        "target" : "184",
        "shared_name" : "Binky (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Binky (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 384,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "382",
        "source" : "192",
        "target" : "184",
        "shared_name" : "Binky (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Binky (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 382,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "380",
        "source" : "192",
        "target" : "184",
        "shared_name" : "Binky (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Binky (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 380,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "378",
        "source" : "192",
        "target" : "184",
        "shared_name" : "Binky (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Binky (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 378,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "376",
        "source" : "192",
        "target" : "184",
        "shared_name" : "Binky (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Binky (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 376,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "374",
        "source" : "192",
        "target" : "184",
        "shared_name" : "Binky (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Binky (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 374,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "372",
        "source" : "192",
        "target" : "184",
        "shared_name" : "Binky (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Binky (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 372,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "370",
        "source" : "192",
        "target" : "184",
        "shared_name" : "Binky (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Binky (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 370,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "368",
        "source" : "192",
        "target" : "184",
        "shared_name" : "Binky (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Binky (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 368,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "366",
        "source" : "190",
        "target" : "184",
        "shared_name" : "Jane (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Jane (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 366,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "364",
        "source" : "190",
        "target" : "184",
        "shared_name" : "Jane (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Jane (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 364,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "362",
        "source" : "190",
        "target" : "184",
        "shared_name" : "Jane (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Jane (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 362,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "360",
        "source" : "190",
        "target" : "184",
        "shared_name" : "Jane (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Jane (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 360,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "358",
        "source" : "190",
        "target" : "184",
        "shared_name" : "Jane (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Jane (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 358,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "356",
        "source" : "190",
        "target" : "184",
        "shared_name" : "Jane (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Jane (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 356,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "354",
        "source" : "190",
        "target" : "184",
        "shared_name" : "Jane (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Jane (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 354,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "352",
        "source" : "190",
        "target" : "184",
        "shared_name" : "Jane (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Jane (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 352,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "350",
        "source" : "190",
        "target" : "184",
        "shared_name" : "Jane (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Jane (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 350,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "348",
        "source" : "190",
        "target" : "184",
        "shared_name" : "Jane (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Jane (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 348,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "346",
        "source" : "190",
        "target" : "184",
        "shared_name" : "Jane (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Jane (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 346,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "344",
        "source" : "190",
        "target" : "184",
        "shared_name" : "Jane (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Jane (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 344,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "342",
        "source" : "190",
        "target" : "184",
        "shared_name" : "Jane (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Jane (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 342,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "340",
        "source" : "190",
        "target" : "184",
        "shared_name" : "Jane (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Jane (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 340,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "338",
        "source" : "190",
        "target" : "184",
        "shared_name" : "Jane (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Jane (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 338,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "336",
        "source" : "190",
        "target" : "184",
        "shared_name" : "Jane (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Jane (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 336,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "334",
        "source" : "188",
        "target" : "184",
        "shared_name" : "Francine Frensky (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Francine Frensky (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 334,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "332",
        "source" : "186",
        "target" : "184",
        "shared_name" : "Brain (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Brain (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 332,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "330",
        "source" : "186",
        "target" : "184",
        "shared_name" : "Brain (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Brain (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 330,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "328",
        "source" : "186",
        "target" : "184",
        "shared_name" : "Brain (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Brain (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 328,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "326",
        "source" : "186",
        "target" : "184",
        "shared_name" : "Brain (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Brain (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 326,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "324",
        "source" : "186",
        "target" : "184",
        "shared_name" : "Brain (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Brain (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 324,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "322",
        "source" : "186",
        "target" : "184",
        "shared_name" : "Brain (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Brain (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 322,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "320",
        "source" : "186",
        "target" : "184",
        "shared_name" : "Brain (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Brain (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 320,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "318",
        "source" : "186",
        "target" : "184",
        "shared_name" : "Brain (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Brain (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 318,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "316",
        "source" : "186",
        "target" : "184",
        "shared_name" : "Brain (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Brain (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 316,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "314",
        "source" : "186",
        "target" : "184",
        "shared_name" : "Brain (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Brain (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 314,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "312",
        "source" : "186",
        "target" : "184",
        "shared_name" : "Brain (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Brain (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 312,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "310",
        "source" : "186",
        "target" : "184",
        "shared_name" : "Brain (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Brain (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 310,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "308",
        "source" : "186",
        "target" : "184",
        "shared_name" : "Brain (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Brain (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 308,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "306",
        "source" : "182",
        "target" : "184",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 306,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "304",
        "source" : "182",
        "target" : "184",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 304,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "302",
        "source" : "182",
        "target" : "184",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 302,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "300",
        "source" : "182",
        "target" : "184",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 300,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "298",
        "source" : "182",
        "target" : "184",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 298,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "296",
        "source" : "182",
        "target" : "184",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 296,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "294",
        "source" : "182",
        "target" : "184",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 294,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "292",
        "source" : "182",
        "target" : "184",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 292,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "290",
        "source" : "182",
        "target" : "184",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 290,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "288",
        "source" : "182",
        "target" : "184",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 288,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "286",
        "source" : "182",
        "target" : "184",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 286,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "284",
        "source" : "182",
        "target" : "184",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 284,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "282",
        "source" : "182",
        "target" : "184",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 282,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "280",
        "source" : "182",
        "target" : "184",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 280,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "278",
        "source" : "182",
        "target" : "184",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 278,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "276",
        "source" : "182",
        "target" : "184",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 276,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "274",
        "source" : "182",
        "target" : "184",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 274,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "272",
        "source" : "182",
        "target" : "184",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 272,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "270",
        "source" : "182",
        "target" : "184",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 270,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "268",
        "source" : "182",
        "target" : "184",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 268,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "266",
        "source" : "182",
        "target" : "184",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 266,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "264",
        "source" : "182",
        "target" : "184",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 264,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "262",
        "source" : "182",
        "target" : "184",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 262,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "260",
        "source" : "182",
        "target" : "184",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 260,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "258",
        "source" : "182",
        "target" : "184",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 258,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "256",
        "source" : "182",
        "target" : "184",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 256,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "254",
        "source" : "182",
        "target" : "184",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 254,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "252",
        "source" : "182",
        "target" : "184",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 252,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "250",
        "source" : "182",
        "target" : "184",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 250,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "248",
        "source" : "182",
        "target" : "184",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 248,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "246",
        "source" : "182",
        "target" : "184",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 246,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "244",
        "source" : "182",
        "target" : "184",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 244,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "242",
        "source" : "182",
        "target" : "184",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 242,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "240",
        "source" : "182",
        "target" : "184",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 240,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "238",
        "source" : "182",
        "target" : "184",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 238,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "236",
        "source" : "182",
        "target" : "184",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 236,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "234",
        "source" : "182",
        "target" : "184",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 234,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "232",
        "source" : "182",
        "target" : "184",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 232,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "230",
        "source" : "182",
        "target" : "184",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 230,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "228",
        "source" : "182",
        "target" : "184",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 228,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "226",
        "source" : "182",
        "target" : "184",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 226,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "224",
        "source" : "182",
        "target" : "184",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 224,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "222",
        "source" : "182",
        "target" : "184",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 222,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "220",
        "source" : "182",
        "target" : "184",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 220,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "218",
        "source" : "182",
        "target" : "184",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 218,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "216",
        "source" : "182",
        "target" : "184",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 216,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "214",
        "source" : "182",
        "target" : "184",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 214,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "212",
        "source" : "182",
        "target" : "184",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 212,
        "selected" : false
      },
      "selected" : false
    } ]
  }
}}