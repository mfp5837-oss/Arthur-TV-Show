var networks = {"3x1.tsv": {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "data" : {
    "shared_name" : "3x1.tsv",
    "name" : "3x1.tsv",
    "SUID" : 468,
    "__Annotations" : [ "edgeThickness=3.0|canvas=foreground|fillOpacity=100.0|color=-16777216|rotation=0.0|type=org.cytoscape.view.presentation.annotations.BoundedTextAnnotation|fontStyle=1|uuid=60ee5a4e-9726-451c-92b3-f0f4de1fedd1|shapeType=ROUNDEDRECTANGLE|edgeColor=-14342875|fontFamily=Serif|edgeOpacity=100.0|name=How many times a characters are mention in S4 E3|x=-741.8203921640554|width=528.6015625|y=-180.56922748461983|z=0|fontSize=24|text=How many times a characters are mention in S4 E3|height=60.760717767876876" ],
    "selected" : true
  },
  "elements" : {
    "nodes" : [ {
      "data" : {
        "id" : "218",
        "shared_name" : "Arthur",
        "name" : "Arthur",
        "SUID" : 218,
        "sceneMarker" : "scene",
        "selected" : false
      },
      "position" : {
        "x" : -46.62799824709474,
        "y" : 249.74984236344793
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "216",
        "shared_name" : "1",
        "name" : "1",
        "SUID" : 216,
        "sceneMarker" : "",
        "selected" : false
      },
      "position" : {
        "x" : 3.439211893076066,
        "y" : 30.391062122537654
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "190",
        "shared_name" : "Brain",
        "name" : "Brain",
        "SUID" : 190,
        "sceneMarker" : "scene",
        "selected" : false
      },
      "position" : {
        "x" : -136.845993525139,
        "y" : 206.30314567784433
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "517",
        "shared_name" : "Francine Frensky",
        "name" : "Francine Frensky",
        "SUID" : 517,
        "sceneMarker" : "scene",
        "selected" : false
      },
      "position" : {
        "x" : 174.77989528153932,
        "y" : -129.3181633613352
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "515",
        "shared_name" : "Jane",
        "name" : "Jane",
        "SUID" : 515,
        "sceneMarker" : "scene",
        "selected" : false
      },
      "position" : {
        "x" : -199.27878338496825,
        "y" : 128.0149034239882
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "513",
        "shared_name" : "Binky",
        "name" : "Binky",
        "SUID" : 513,
        "sceneMarker" : "scene",
        "selected" : false
      },
      "position" : {
        "x" : 206.15720717112038,
        "y" : 128.01490342398824
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "214",
        "shared_name" : "Buster",
        "name" : "Buster",
        "SUID" : 214,
        "sceneMarker" : "scene",
        "selected" : false
      },
      "position" : {
        "x" : -221.56078810692392,
        "y" : 30.391062122537612
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "508",
        "shared_name" : "Sue Ellen",
        "name" : "Sue Ellen",
        "SUID" : 508,
        "sceneMarker" : "scene",
        "selected" : false
      },
      "position" : {
        "x" : -199.2787833849682,
        "y" : -67.23277917891295
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "206",
        "shared_name" : "D.W.",
        "name" : "D.W.",
        "SUID" : 206,
        "sceneMarker" : "scene",
        "selected" : false
      },
      "position" : {
        "x" : 143.72441731129112,
        "y" : 206.30314567784436
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "503",
        "shared_name" : "David Read",
        "name" : "David Read",
        "SUID" : 503,
        "sceneMarker" : "scene",
        "selected" : false
      },
      "position" : {
        "x" : 53.5064220332468,
        "y" : 249.74984236344795
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "501",
        "shared_name" : "David",
        "name" : "David",
        "SUID" : 501,
        "sceneMarker" : "scene",
        "selected" : false
      },
      "position" : {
        "x" : -136.84599352513894,
        "y" : -145.5210214327691
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "499",
        "shared_name" : "Buster, Binky, Brain, and Sue Ellen",
        "name" : "Buster, Binky, Brain, and Sue Ellen",
        "SUID" : 499,
        "sceneMarker" : "scene",
        "selected" : false
      },
      "position" : {
        "x" : -46.62799824709465,
        "y" : -188.96771811837266
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "497",
        "shared_name" : "Arthur, Brain, and Sue Ellen",
        "name" : "Arthur, Brain, and Sue Ellen",
        "SUID" : 497,
        "sceneMarker" : "scene",
        "selected" : false
      },
      "position" : {
        "x" : 121.01833066422117,
        "y" : -188.96771811837266
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "495",
        "shared_name" : "Buster, Binky, Brain and Sue Ellen",
        "name" : "Buster, Binky, Brain and Sue Ellen",
        "SUID" : 495,
        "sceneMarker" : "scene",
        "selected" : false
      },
      "position" : {
        "x" : 254.09373717284632,
        "y" : 54.69534922968843
      },
      "selected" : false
    } ],
    "edges" : [ {
      "data" : {
        "id" : "776",
        "source" : "218",
        "target" : "216",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 776,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "774",
        "source" : "218",
        "target" : "216",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 774,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "772",
        "source" : "218",
        "target" : "216",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 772,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "770",
        "source" : "218",
        "target" : "216",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 770,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "768",
        "source" : "218",
        "target" : "216",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 768,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "766",
        "source" : "218",
        "target" : "216",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 766,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "764",
        "source" : "218",
        "target" : "216",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 764,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "762",
        "source" : "218",
        "target" : "216",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 762,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "760",
        "source" : "218",
        "target" : "216",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 760,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "758",
        "source" : "218",
        "target" : "216",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 758,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "756",
        "source" : "218",
        "target" : "216",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 756,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "754",
        "source" : "218",
        "target" : "216",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 754,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "752",
        "source" : "218",
        "target" : "216",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 752,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "750",
        "source" : "218",
        "target" : "216",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 750,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "748",
        "source" : "218",
        "target" : "216",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 748,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "746",
        "source" : "218",
        "target" : "216",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 746,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "744",
        "source" : "218",
        "target" : "216",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 744,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "742",
        "source" : "218",
        "target" : "216",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 742,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "740",
        "source" : "218",
        "target" : "216",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 740,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "738",
        "source" : "218",
        "target" : "216",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 738,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "736",
        "source" : "218",
        "target" : "216",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 736,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "734",
        "source" : "218",
        "target" : "216",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 734,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "732",
        "source" : "218",
        "target" : "216",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 732,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "730",
        "source" : "218",
        "target" : "216",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 730,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "728",
        "source" : "218",
        "target" : "216",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 728,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "726",
        "source" : "218",
        "target" : "216",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 726,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "724",
        "source" : "218",
        "target" : "216",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 724,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "722",
        "source" : "218",
        "target" : "216",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 722,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "720",
        "source" : "218",
        "target" : "216",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 720,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "718",
        "source" : "218",
        "target" : "216",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 718,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "716",
        "source" : "218",
        "target" : "216",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 716,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "714",
        "source" : "218",
        "target" : "216",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 714,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "712",
        "source" : "218",
        "target" : "216",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 712,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "710",
        "source" : "218",
        "target" : "216",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 710,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "708",
        "source" : "218",
        "target" : "216",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 708,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "706",
        "source" : "218",
        "target" : "216",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 706,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "704",
        "source" : "218",
        "target" : "216",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 704,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "702",
        "source" : "218",
        "target" : "216",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 702,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "700",
        "source" : "218",
        "target" : "216",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 700,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "698",
        "source" : "218",
        "target" : "216",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 698,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "696",
        "source" : "218",
        "target" : "216",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 696,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "694",
        "source" : "218",
        "target" : "216",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 694,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "692",
        "source" : "218",
        "target" : "216",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 692,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "690",
        "source" : "218",
        "target" : "216",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 690,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "688",
        "source" : "218",
        "target" : "216",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 688,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "686",
        "source" : "218",
        "target" : "216",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 686,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "684",
        "source" : "218",
        "target" : "216",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 684,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "682",
        "source" : "218",
        "target" : "216",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 682,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "680",
        "source" : "190",
        "target" : "216",
        "shared_name" : "Brain (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Brain (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 680,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "678",
        "source" : "190",
        "target" : "216",
        "shared_name" : "Brain (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Brain (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 678,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "676",
        "source" : "190",
        "target" : "216",
        "shared_name" : "Brain (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Brain (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 676,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "674",
        "source" : "190",
        "target" : "216",
        "shared_name" : "Brain (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Brain (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 674,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "672",
        "source" : "190",
        "target" : "216",
        "shared_name" : "Brain (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Brain (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 672,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "670",
        "source" : "190",
        "target" : "216",
        "shared_name" : "Brain (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Brain (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 670,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "668",
        "source" : "190",
        "target" : "216",
        "shared_name" : "Brain (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Brain (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 668,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "666",
        "source" : "190",
        "target" : "216",
        "shared_name" : "Brain (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Brain (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 666,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "664",
        "source" : "190",
        "target" : "216",
        "shared_name" : "Brain (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Brain (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 664,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "662",
        "source" : "190",
        "target" : "216",
        "shared_name" : "Brain (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Brain (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 662,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "660",
        "source" : "190",
        "target" : "216",
        "shared_name" : "Brain (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Brain (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 660,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "658",
        "source" : "190",
        "target" : "216",
        "shared_name" : "Brain (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Brain (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 658,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "656",
        "source" : "190",
        "target" : "216",
        "shared_name" : "Brain (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Brain (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 656,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "654",
        "source" : "517",
        "target" : "216",
        "shared_name" : "Francine Frensky (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Francine Frensky (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 654,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "652",
        "source" : "515",
        "target" : "216",
        "shared_name" : "Jane (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Jane (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 652,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "650",
        "source" : "515",
        "target" : "216",
        "shared_name" : "Jane (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Jane (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 650,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "648",
        "source" : "515",
        "target" : "216",
        "shared_name" : "Jane (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Jane (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 648,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "646",
        "source" : "515",
        "target" : "216",
        "shared_name" : "Jane (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Jane (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 646,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "644",
        "source" : "515",
        "target" : "216",
        "shared_name" : "Jane (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Jane (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 644,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "642",
        "source" : "515",
        "target" : "216",
        "shared_name" : "Jane (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Jane (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 642,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "640",
        "source" : "515",
        "target" : "216",
        "shared_name" : "Jane (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Jane (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 640,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "638",
        "source" : "515",
        "target" : "216",
        "shared_name" : "Jane (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Jane (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 638,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "636",
        "source" : "515",
        "target" : "216",
        "shared_name" : "Jane (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Jane (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 636,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "634",
        "source" : "515",
        "target" : "216",
        "shared_name" : "Jane (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Jane (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 634,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "632",
        "source" : "515",
        "target" : "216",
        "shared_name" : "Jane (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Jane (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 632,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "630",
        "source" : "515",
        "target" : "216",
        "shared_name" : "Jane (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Jane (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 630,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "628",
        "source" : "515",
        "target" : "216",
        "shared_name" : "Jane (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Jane (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 628,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "626",
        "source" : "515",
        "target" : "216",
        "shared_name" : "Jane (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Jane (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 626,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "624",
        "source" : "515",
        "target" : "216",
        "shared_name" : "Jane (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Jane (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 624,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "622",
        "source" : "515",
        "target" : "216",
        "shared_name" : "Jane (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Jane (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 622,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "620",
        "source" : "513",
        "target" : "216",
        "shared_name" : "Binky (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Binky (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 620,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "618",
        "source" : "513",
        "target" : "216",
        "shared_name" : "Binky (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Binky (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 618,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "616",
        "source" : "513",
        "target" : "216",
        "shared_name" : "Binky (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Binky (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 616,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "614",
        "source" : "513",
        "target" : "216",
        "shared_name" : "Binky (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Binky (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 614,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "612",
        "source" : "513",
        "target" : "216",
        "shared_name" : "Binky (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Binky (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 612,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "610",
        "source" : "513",
        "target" : "216",
        "shared_name" : "Binky (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Binky (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 610,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "608",
        "source" : "513",
        "target" : "216",
        "shared_name" : "Binky (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Binky (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 608,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "606",
        "source" : "513",
        "target" : "216",
        "shared_name" : "Binky (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Binky (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 606,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "604",
        "source" : "513",
        "target" : "216",
        "shared_name" : "Binky (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Binky (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 604,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "602",
        "source" : "513",
        "target" : "216",
        "shared_name" : "Binky (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Binky (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 602,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "600",
        "source" : "513",
        "target" : "216",
        "shared_name" : "Binky (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Binky (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 600,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "598",
        "source" : "513",
        "target" : "216",
        "shared_name" : "Binky (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Binky (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 598,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "596",
        "source" : "214",
        "target" : "216",
        "shared_name" : "Buster (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Buster (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 596,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "594",
        "source" : "214",
        "target" : "216",
        "shared_name" : "Buster (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Buster (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 594,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "592",
        "source" : "214",
        "target" : "216",
        "shared_name" : "Buster (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Buster (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 592,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "590",
        "source" : "214",
        "target" : "216",
        "shared_name" : "Buster (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Buster (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 590,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "588",
        "source" : "214",
        "target" : "216",
        "shared_name" : "Buster (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Buster (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 588,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "586",
        "source" : "214",
        "target" : "216",
        "shared_name" : "Buster (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Buster (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 586,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "584",
        "source" : "214",
        "target" : "216",
        "shared_name" : "Buster (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Buster (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 584,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "582",
        "source" : "214",
        "target" : "216",
        "shared_name" : "Buster (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Buster (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 582,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "580",
        "source" : "508",
        "target" : "216",
        "shared_name" : "Sue Ellen (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Sue Ellen (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 580,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "578",
        "source" : "508",
        "target" : "216",
        "shared_name" : "Sue Ellen (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Sue Ellen (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 578,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "576",
        "source" : "508",
        "target" : "216",
        "shared_name" : "Sue Ellen (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Sue Ellen (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 576,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "574",
        "source" : "508",
        "target" : "216",
        "shared_name" : "Sue Ellen (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Sue Ellen (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 574,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "572",
        "source" : "508",
        "target" : "216",
        "shared_name" : "Sue Ellen (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Sue Ellen (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 572,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "570",
        "source" : "508",
        "target" : "216",
        "shared_name" : "Sue Ellen (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Sue Ellen (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 570,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "568",
        "source" : "508",
        "target" : "216",
        "shared_name" : "Sue Ellen (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Sue Ellen (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 568,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "566",
        "source" : "508",
        "target" : "216",
        "shared_name" : "Sue Ellen (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Sue Ellen (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 566,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "564",
        "source" : "508",
        "target" : "216",
        "shared_name" : "Sue Ellen (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Sue Ellen (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 564,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "562",
        "source" : "508",
        "target" : "216",
        "shared_name" : "Sue Ellen (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Sue Ellen (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 562,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "560",
        "source" : "508",
        "target" : "216",
        "shared_name" : "Sue Ellen (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Sue Ellen (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 560,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "558",
        "source" : "206",
        "target" : "216",
        "shared_name" : "D.W. (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "D.W. (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 558,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "556",
        "source" : "206",
        "target" : "216",
        "shared_name" : "D.W. (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "D.W. (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 556,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "554",
        "source" : "206",
        "target" : "216",
        "shared_name" : "D.W. (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "D.W. (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 554,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "552",
        "source" : "206",
        "target" : "216",
        "shared_name" : "D.W. (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "D.W. (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 552,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "550",
        "source" : "206",
        "target" : "216",
        "shared_name" : "D.W. (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "D.W. (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 550,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "548",
        "source" : "503",
        "target" : "216",
        "shared_name" : "David Read (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "David Read (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 548,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "546",
        "source" : "501",
        "target" : "216",
        "shared_name" : "David (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "David (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 546,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "544",
        "source" : "501",
        "target" : "216",
        "shared_name" : "David (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "David (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 544,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "542",
        "source" : "501",
        "target" : "216",
        "shared_name" : "David (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "David (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 542,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "540",
        "source" : "501",
        "target" : "216",
        "shared_name" : "David (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "David (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 540,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "538",
        "source" : "501",
        "target" : "216",
        "shared_name" : "David (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "David (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 538,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "536",
        "source" : "501",
        "target" : "216",
        "shared_name" : "David (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "David (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 536,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "534",
        "source" : "501",
        "target" : "216",
        "shared_name" : "David (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "David (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 534,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "532",
        "source" : "499",
        "target" : "216",
        "shared_name" : "Buster, Binky, Brain, and Sue Ellen (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Buster, Binky, Brain, and Sue Ellen (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 532,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "530",
        "source" : "497",
        "target" : "216",
        "shared_name" : "Arthur, Brain, and Sue Ellen (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur, Brain, and Sue Ellen (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 530,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "528",
        "source" : "495",
        "target" : "216",
        "shared_name" : "Buster, Binky, Brain and Sue Ellen (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Buster, Binky, Brain and Sue Ellen (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 528,
        "selected" : false
      },
      "selected" : false
    } ]
  }
},"4x3.tsv": {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "data" : {
    "shared_name" : "4x3.tsv",
    "name" : "4x3.tsv",
    "SUID" : 155,
    "__Annotations" : [ "" ],
    "selected" : false
  },
  "elements" : {
    "nodes" : [ {
      "data" : {
        "id" : "218",
        "shared_name" : "Arthur",
        "name" : "Arthur",
        "SUID" : 218,
        "sceneMarker" : "scene",
        "selected" : false
      },
      "position" : {
        "x" : 15.14895790501646,
        "y" : -27.26272593046488
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "216",
        "shared_name" : "1",
        "name" : "1",
        "SUID" : 216,
        "sceneMarker" : "",
        "selected" : false
      },
      "position" : {
        "x" : 78.38571327611021,
        "y" : -120.67931185270609
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "214",
        "shared_name" : "Buster",
        "name" : "Buster",
        "SUID" : 214,
        "sceneMarker" : "scene",
        "selected" : false
      },
      "position" : {
        "x" : 77.46063393040708,
        "y" : -21.942451577437538
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "212",
        "shared_name" : "Kate",
        "name" : "Kate",
        "SUID" : 212,
        "sceneMarker" : "scene",
        "selected" : false
      },
      "position" : {
        "x" : 149.27996986790708,
        "y" : -219.73275766874613
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "210",
        "shared_name" : "Mrs. Read",
        "name" : "Mrs. Read",
        "SUID" : 210,
        "sceneMarker" : "scene",
        "selected" : false
      },
      "position" : {
        "x" : 2.5108048288445843,
        "y" : -74.20690928007426
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "208",
        "shared_name" : "2",
        "name" : "2",
        "SUID" : 208,
        "sceneMarker" : "",
        "selected" : false
      },
      "position" : {
        "x" : -88.80013877467104,
        "y" : -10.000763039839882
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "206",
        "shared_name" : "D.W.",
        "name" : "D.W.",
        "SUID" : 206,
        "sceneMarker" : "scene",
        "selected" : false
      },
      "position" : {
        "x" : -78.67257529810854,
        "y" : 68.56989278291402
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "204",
        "shared_name" : "Mr. Read",
        "name" : "Mr. Read",
        "SUID" : 204,
        "sceneMarker" : "scene",
        "selected" : false
      },
      "position" : {
        "x" : -35.14602500513979,
        "y" : 100.81938924287496
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "202",
        "shared_name" : "Francine",
        "name" : "Francine",
        "SUID" : 202,
        "sceneMarker" : "scene",
        "selected" : false
      },
      "position" : {
        "x" : -196.88358909205385,
        "y" : -37.74633799101176
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "200",
        "shared_name" : "Umpire",
        "name" : "Umpire",
        "SUID" : 200,
        "sceneMarker" : "scene",
        "selected" : false
      },
      "position" : {
        "x" : -200.16993552760073,
        "y" : 64.3500136325234
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "198",
        "shared_name" : "Muffy",
        "name" : "Muffy",
        "SUID" : 198,
        "sceneMarker" : "scene",
        "selected" : false
      },
      "position" : {
        "x" : -107.70010215357729,
        "y" : -178.2127533962852
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "196",
        "shared_name" : "3",
        "name" : "3",
        "SUID" : 196,
        "sceneMarker" : "",
        "selected" : false
      },
      "position" : {
        "x" : -89.93551475123354,
        "y" : -49.46062098051371
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "194",
        "shared_name" : "Mrs. Baxter",
        "name" : "Mrs. Baxter",
        "SUID" : 194,
        "sceneMarker" : "scene",
        "selected" : false
      },
      "position" : {
        "x" : -193.05221396998354,
        "y" : -130.04553614164652
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "192",
        "shared_name" : "4",
        "name" : "4",
        "SUID" : 192,
        "sceneMarker" : "",
        "selected" : false
      },
      "position" : {
        "x" : 71.44555824681333,
        "y" : 63.764900107132775
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "190",
        "shared_name" : "Brain",
        "name" : "Brain",
        "SUID" : 190,
        "sceneMarker" : "scene",
        "selected" : false
      },
      "position" : {
        "x" : 140.39203041478208,
        "y" : 177.10678853486715
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "188",
        "shared_name" : "Prunella",
        "name" : "Prunella",
        "SUID" : 188,
        "sceneMarker" : "scene",
        "selected" : false
      },
      "position" : {
        "x" : 178.22693031712583,
        "y" : 104.56835164521871
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "186",
        "shared_name" : "Vision of Arthur",
        "name" : "Vision of Arthur",
        "SUID" : 186,
        "sceneMarker" : "scene",
        "selected" : false
      },
      "position" : {
        "x" : 196.18286293431333,
        "y" : 26.007377524124962
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "184",
        "shared_name" : "Vision of Buster",
        "name" : "Vision of Buster",
        "SUID" : 184,
        "sceneMarker" : "scene",
        "selected" : false
      },
      "position" : {
        "x" : 56.23990028782896,
        "y" : 195.27460469697652
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "182",
        "shared_name" : "5",
        "name" : "5",
        "SUID" : 182,
        "sceneMarker" : "",
        "selected" : false
      },
      "position" : {
        "x" : 25.086732563219584,
        "y" : 68.82884969209371
      },
      "selected" : false
    } ],
    "edges" : [ {
      "data" : {
        "id" : "466",
        "source" : "218",
        "target" : "216",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 466,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "464",
        "source" : "218",
        "target" : "216",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 464,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "462",
        "source" : "218",
        "target" : "216",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 462,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "460",
        "source" : "218",
        "target" : "216",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 460,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "458",
        "source" : "218",
        "target" : "216",
        "shared_name" : "Arthur (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 458,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "456",
        "source" : "218",
        "target" : "208",
        "shared_name" : "Arthur (interacts with) 2",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 2",
        "interaction" : "interacts with",
        "SUID" : 456,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "454",
        "source" : "218",
        "target" : "208",
        "shared_name" : "Arthur (interacts with) 2",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 2",
        "interaction" : "interacts with",
        "SUID" : 454,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "452",
        "source" : "218",
        "target" : "208",
        "shared_name" : "Arthur (interacts with) 2",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 2",
        "interaction" : "interacts with",
        "SUID" : 452,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "450",
        "source" : "218",
        "target" : "208",
        "shared_name" : "Arthur (interacts with) 2",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 2",
        "interaction" : "interacts with",
        "SUID" : 450,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "448",
        "source" : "218",
        "target" : "208",
        "shared_name" : "Arthur (interacts with) 2",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 2",
        "interaction" : "interacts with",
        "SUID" : 448,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "446",
        "source" : "218",
        "target" : "208",
        "shared_name" : "Arthur (interacts with) 2",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 2",
        "interaction" : "interacts with",
        "SUID" : 446,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "444",
        "source" : "218",
        "target" : "208",
        "shared_name" : "Arthur (interacts with) 2",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 2",
        "interaction" : "interacts with",
        "SUID" : 444,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "442",
        "source" : "218",
        "target" : "208",
        "shared_name" : "Arthur (interacts with) 2",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 2",
        "interaction" : "interacts with",
        "SUID" : 442,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "440",
        "source" : "218",
        "target" : "208",
        "shared_name" : "Arthur (interacts with) 2",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 2",
        "interaction" : "interacts with",
        "SUID" : 440,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "438",
        "source" : "218",
        "target" : "196",
        "shared_name" : "Arthur (interacts with) 3",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 3",
        "interaction" : "interacts with",
        "SUID" : 438,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "436",
        "source" : "218",
        "target" : "196",
        "shared_name" : "Arthur (interacts with) 3",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 3",
        "interaction" : "interacts with",
        "SUID" : 436,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "434",
        "source" : "218",
        "target" : "196",
        "shared_name" : "Arthur (interacts with) 3",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 3",
        "interaction" : "interacts with",
        "SUID" : 434,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "432",
        "source" : "218",
        "target" : "196",
        "shared_name" : "Arthur (interacts with) 3",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 3",
        "interaction" : "interacts with",
        "SUID" : 432,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "430",
        "source" : "218",
        "target" : "196",
        "shared_name" : "Arthur (interacts with) 3",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 3",
        "interaction" : "interacts with",
        "SUID" : 430,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "428",
        "source" : "218",
        "target" : "196",
        "shared_name" : "Arthur (interacts with) 3",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 3",
        "interaction" : "interacts with",
        "SUID" : 428,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "426",
        "source" : "218",
        "target" : "196",
        "shared_name" : "Arthur (interacts with) 3",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 3",
        "interaction" : "interacts with",
        "SUID" : 426,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "424",
        "source" : "218",
        "target" : "196",
        "shared_name" : "Arthur (interacts with) 3",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 3",
        "interaction" : "interacts with",
        "SUID" : 424,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "422",
        "source" : "218",
        "target" : "192",
        "shared_name" : "Arthur (interacts with) 4",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 4",
        "interaction" : "interacts with",
        "SUID" : 422,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "420",
        "source" : "218",
        "target" : "192",
        "shared_name" : "Arthur (interacts with) 4",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 4",
        "interaction" : "interacts with",
        "SUID" : 420,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "418",
        "source" : "218",
        "target" : "192",
        "shared_name" : "Arthur (interacts with) 4",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 4",
        "interaction" : "interacts with",
        "SUID" : 418,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "416",
        "source" : "218",
        "target" : "192",
        "shared_name" : "Arthur (interacts with) 4",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 4",
        "interaction" : "interacts with",
        "SUID" : 416,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "414",
        "source" : "218",
        "target" : "192",
        "shared_name" : "Arthur (interacts with) 4",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 4",
        "interaction" : "interacts with",
        "SUID" : 414,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "412",
        "source" : "218",
        "target" : "192",
        "shared_name" : "Arthur (interacts with) 4",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 4",
        "interaction" : "interacts with",
        "SUID" : 412,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "410",
        "source" : "218",
        "target" : "192",
        "shared_name" : "Arthur (interacts with) 4",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 4",
        "interaction" : "interacts with",
        "SUID" : 410,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "408",
        "source" : "218",
        "target" : "192",
        "shared_name" : "Arthur (interacts with) 4",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 4",
        "interaction" : "interacts with",
        "SUID" : 408,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "406",
        "source" : "218",
        "target" : "192",
        "shared_name" : "Arthur (interacts with) 4",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 4",
        "interaction" : "interacts with",
        "SUID" : 406,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "404",
        "source" : "218",
        "target" : "192",
        "shared_name" : "Arthur (interacts with) 4",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 4",
        "interaction" : "interacts with",
        "SUID" : 404,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "402",
        "source" : "218",
        "target" : "192",
        "shared_name" : "Arthur (interacts with) 4",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 4",
        "interaction" : "interacts with",
        "SUID" : 402,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "400",
        "source" : "218",
        "target" : "192",
        "shared_name" : "Arthur (interacts with) 4",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 4",
        "interaction" : "interacts with",
        "SUID" : 400,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "398",
        "source" : "218",
        "target" : "192",
        "shared_name" : "Arthur (interacts with) 4",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 4",
        "interaction" : "interacts with",
        "SUID" : 398,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "396",
        "source" : "218",
        "target" : "192",
        "shared_name" : "Arthur (interacts with) 4",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 4",
        "interaction" : "interacts with",
        "SUID" : 396,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "394",
        "source" : "218",
        "target" : "192",
        "shared_name" : "Arthur (interacts with) 4",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 4",
        "interaction" : "interacts with",
        "SUID" : 394,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "392",
        "source" : "218",
        "target" : "192",
        "shared_name" : "Arthur (interacts with) 4",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 4",
        "interaction" : "interacts with",
        "SUID" : 392,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "390",
        "source" : "218",
        "target" : "192",
        "shared_name" : "Arthur (interacts with) 4",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 4",
        "interaction" : "interacts with",
        "SUID" : 390,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "388",
        "source" : "218",
        "target" : "192",
        "shared_name" : "Arthur (interacts with) 4",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 4",
        "interaction" : "interacts with",
        "SUID" : 388,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "386",
        "source" : "218",
        "target" : "182",
        "shared_name" : "Arthur (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 386,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "384",
        "source" : "218",
        "target" : "182",
        "shared_name" : "Arthur (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 384,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "382",
        "source" : "218",
        "target" : "182",
        "shared_name" : "Arthur (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 382,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "380",
        "source" : "218",
        "target" : "182",
        "shared_name" : "Arthur (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 380,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "378",
        "source" : "218",
        "target" : "182",
        "shared_name" : "Arthur (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 378,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "376",
        "source" : "218",
        "target" : "182",
        "shared_name" : "Arthur (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 376,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "374",
        "source" : "218",
        "target" : "182",
        "shared_name" : "Arthur (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 374,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "372",
        "source" : "218",
        "target" : "182",
        "shared_name" : "Arthur (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 372,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "370",
        "source" : "218",
        "target" : "182",
        "shared_name" : "Arthur (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 370,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "368",
        "source" : "218",
        "target" : "182",
        "shared_name" : "Arthur (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 368,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "366",
        "source" : "218",
        "target" : "182",
        "shared_name" : "Arthur (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 366,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "364",
        "source" : "218",
        "target" : "182",
        "shared_name" : "Arthur (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 364,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "362",
        "source" : "218",
        "target" : "182",
        "shared_name" : "Arthur (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 362,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "360",
        "source" : "218",
        "target" : "182",
        "shared_name" : "Arthur (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 360,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "358",
        "source" : "218",
        "target" : "182",
        "shared_name" : "Arthur (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 358,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "356",
        "source" : "218",
        "target" : "182",
        "shared_name" : "Arthur (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 356,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "354",
        "source" : "218",
        "target" : "182",
        "shared_name" : "Arthur (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 354,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "352",
        "source" : "218",
        "target" : "182",
        "shared_name" : "Arthur (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Arthur (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 352,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "350",
        "source" : "214",
        "target" : "216",
        "shared_name" : "Buster (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Buster (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 350,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "348",
        "source" : "214",
        "target" : "216",
        "shared_name" : "Buster (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Buster (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 348,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "346",
        "source" : "214",
        "target" : "216",
        "shared_name" : "Buster (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Buster (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 346,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "344",
        "source" : "214",
        "target" : "216",
        "shared_name" : "Buster (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Buster (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 344,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "342",
        "source" : "214",
        "target" : "192",
        "shared_name" : "Buster (interacts with) 4",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Buster (interacts with) 4",
        "interaction" : "interacts with",
        "SUID" : 342,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "340",
        "source" : "214",
        "target" : "192",
        "shared_name" : "Buster (interacts with) 4",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Buster (interacts with) 4",
        "interaction" : "interacts with",
        "SUID" : 340,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "338",
        "source" : "214",
        "target" : "192",
        "shared_name" : "Buster (interacts with) 4",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Buster (interacts with) 4",
        "interaction" : "interacts with",
        "SUID" : 338,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "336",
        "source" : "214",
        "target" : "192",
        "shared_name" : "Buster (interacts with) 4",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Buster (interacts with) 4",
        "interaction" : "interacts with",
        "SUID" : 336,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "334",
        "source" : "214",
        "target" : "192",
        "shared_name" : "Buster (interacts with) 4",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Buster (interacts with) 4",
        "interaction" : "interacts with",
        "SUID" : 334,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "332",
        "source" : "214",
        "target" : "182",
        "shared_name" : "Buster (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Buster (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 332,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "330",
        "source" : "214",
        "target" : "182",
        "shared_name" : "Buster (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Buster (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 330,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "328",
        "source" : "214",
        "target" : "182",
        "shared_name" : "Buster (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Buster (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 328,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "326",
        "source" : "214",
        "target" : "182",
        "shared_name" : "Buster (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Buster (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 326,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "324",
        "source" : "214",
        "target" : "182",
        "shared_name" : "Buster (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Buster (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 324,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "322",
        "source" : "214",
        "target" : "182",
        "shared_name" : "Buster (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Buster (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 322,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "320",
        "source" : "214",
        "target" : "182",
        "shared_name" : "Buster (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Buster (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 320,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "318",
        "source" : "214",
        "target" : "182",
        "shared_name" : "Buster (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Buster (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 318,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "316",
        "source" : "214",
        "target" : "182",
        "shared_name" : "Buster (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Buster (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 316,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "314",
        "source" : "214",
        "target" : "182",
        "shared_name" : "Buster (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Buster (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 314,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "312",
        "source" : "214",
        "target" : "182",
        "shared_name" : "Buster (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Buster (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 312,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "310",
        "source" : "214",
        "target" : "182",
        "shared_name" : "Buster (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Buster (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 310,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "308",
        "source" : "214",
        "target" : "182",
        "shared_name" : "Buster (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Buster (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 308,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "306",
        "source" : "214",
        "target" : "182",
        "shared_name" : "Buster (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Buster (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 306,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "304",
        "source" : "214",
        "target" : "182",
        "shared_name" : "Buster (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Buster (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 304,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "302",
        "source" : "214",
        "target" : "182",
        "shared_name" : "Buster (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Buster (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 302,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "300",
        "source" : "214",
        "target" : "182",
        "shared_name" : "Buster (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Buster (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 300,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "298",
        "source" : "214",
        "target" : "182",
        "shared_name" : "Buster (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Buster (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 298,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "296",
        "source" : "214",
        "target" : "182",
        "shared_name" : "Buster (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Buster (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 296,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "294",
        "source" : "212",
        "target" : "216",
        "shared_name" : "Kate (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Kate (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 294,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "292",
        "source" : "210",
        "target" : "216",
        "shared_name" : "Mrs. Read (interacts with) 1",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Mrs. Read (interacts with) 1",
        "interaction" : "interacts with",
        "SUID" : 292,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "290",
        "source" : "210",
        "target" : "208",
        "shared_name" : "Mrs. Read (interacts with) 2",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Mrs. Read (interacts with) 2",
        "interaction" : "interacts with",
        "SUID" : 290,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "288",
        "source" : "210",
        "target" : "196",
        "shared_name" : "Mrs. Read (interacts with) 3",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Mrs. Read (interacts with) 3",
        "interaction" : "interacts with",
        "SUID" : 288,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "286",
        "source" : "210",
        "target" : "192",
        "shared_name" : "Mrs. Read (interacts with) 4",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Mrs. Read (interacts with) 4",
        "interaction" : "interacts with",
        "SUID" : 286,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "284",
        "source" : "206",
        "target" : "208",
        "shared_name" : "D.W. (interacts with) 2",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "D.W. (interacts with) 2",
        "interaction" : "interacts with",
        "SUID" : 284,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "282",
        "source" : "206",
        "target" : "208",
        "shared_name" : "D.W. (interacts with) 2",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "D.W. (interacts with) 2",
        "interaction" : "interacts with",
        "SUID" : 282,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "280",
        "source" : "206",
        "target" : "208",
        "shared_name" : "D.W. (interacts with) 2",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "D.W. (interacts with) 2",
        "interaction" : "interacts with",
        "SUID" : 280,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "278",
        "source" : "206",
        "target" : "208",
        "shared_name" : "D.W. (interacts with) 2",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "D.W. (interacts with) 2",
        "interaction" : "interacts with",
        "SUID" : 278,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "276",
        "source" : "206",
        "target" : "196",
        "shared_name" : "D.W. (interacts with) 3",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "D.W. (interacts with) 3",
        "interaction" : "interacts with",
        "SUID" : 276,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "274",
        "source" : "206",
        "target" : "196",
        "shared_name" : "D.W. (interacts with) 3",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "D.W. (interacts with) 3",
        "interaction" : "interacts with",
        "SUID" : 274,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "272",
        "source" : "206",
        "target" : "196",
        "shared_name" : "D.W. (interacts with) 3",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "D.W. (interacts with) 3",
        "interaction" : "interacts with",
        "SUID" : 272,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "270",
        "source" : "206",
        "target" : "196",
        "shared_name" : "D.W. (interacts with) 3",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "D.W. (interacts with) 3",
        "interaction" : "interacts with",
        "SUID" : 270,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "268",
        "source" : "206",
        "target" : "196",
        "shared_name" : "D.W. (interacts with) 3",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "D.W. (interacts with) 3",
        "interaction" : "interacts with",
        "SUID" : 268,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "266",
        "source" : "206",
        "target" : "182",
        "shared_name" : "D.W. (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "D.W. (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 266,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "264",
        "source" : "206",
        "target" : "182",
        "shared_name" : "D.W. (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "D.W. (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 264,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "262",
        "source" : "206",
        "target" : "182",
        "shared_name" : "D.W. (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "D.W. (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 262,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "260",
        "source" : "206",
        "target" : "182",
        "shared_name" : "D.W. (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "D.W. (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 260,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "258",
        "source" : "206",
        "target" : "182",
        "shared_name" : "D.W. (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "D.W. (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 258,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "256",
        "source" : "206",
        "target" : "182",
        "shared_name" : "D.W. (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "D.W. (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 256,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "254",
        "source" : "206",
        "target" : "182",
        "shared_name" : "D.W. (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "D.W. (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 254,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "252",
        "source" : "206",
        "target" : "182",
        "shared_name" : "D.W. (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "D.W. (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 252,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "250",
        "source" : "206",
        "target" : "182",
        "shared_name" : "D.W. (interacts with) 5",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "D.W. (interacts with) 5",
        "interaction" : "interacts with",
        "SUID" : 250,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "248",
        "source" : "204",
        "target" : "208",
        "shared_name" : "Mr. Read (interacts with) 2",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Mr. Read (interacts with) 2",
        "interaction" : "interacts with",
        "SUID" : 248,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "246",
        "source" : "204",
        "target" : "208",
        "shared_name" : "Mr. Read (interacts with) 2",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Mr. Read (interacts with) 2",
        "interaction" : "interacts with",
        "SUID" : 246,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "244",
        "source" : "204",
        "target" : "192",
        "shared_name" : "Mr. Read (interacts with) 4",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Mr. Read (interacts with) 4",
        "interaction" : "interacts with",
        "SUID" : 244,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "242",
        "source" : "204",
        "target" : "192",
        "shared_name" : "Mr. Read (interacts with) 4",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Mr. Read (interacts with) 4",
        "interaction" : "interacts with",
        "SUID" : 242,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "240",
        "source" : "202",
        "target" : "208",
        "shared_name" : "Francine (interacts with) 2",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Francine (interacts with) 2",
        "interaction" : "interacts with",
        "SUID" : 240,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "238",
        "source" : "202",
        "target" : "208",
        "shared_name" : "Francine (interacts with) 2",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Francine (interacts with) 2",
        "interaction" : "interacts with",
        "SUID" : 238,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "236",
        "source" : "202",
        "target" : "196",
        "shared_name" : "Francine (interacts with) 3",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Francine (interacts with) 3",
        "interaction" : "interacts with",
        "SUID" : 236,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "234",
        "source" : "200",
        "target" : "208",
        "shared_name" : "Umpire (interacts with) 2",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Umpire (interacts with) 2",
        "interaction" : "interacts with",
        "SUID" : 234,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "232",
        "source" : "198",
        "target" : "196",
        "shared_name" : "Muffy (interacts with) 3",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Muffy (interacts with) 3",
        "interaction" : "interacts with",
        "SUID" : 232,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "230",
        "source" : "194",
        "target" : "196",
        "shared_name" : "Mrs. Baxter (interacts with) 3",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Mrs. Baxter (interacts with) 3",
        "interaction" : "interacts with",
        "SUID" : 230,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "228",
        "source" : "190",
        "target" : "192",
        "shared_name" : "Brain (interacts with) 4",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Brain (interacts with) 4",
        "interaction" : "interacts with",
        "SUID" : 228,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "226",
        "source" : "188",
        "target" : "192",
        "shared_name" : "Prunella (interacts with) 4",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Prunella (interacts with) 4",
        "interaction" : "interacts with",
        "SUID" : 226,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "224",
        "source" : "188",
        "target" : "192",
        "shared_name" : "Prunella (interacts with) 4",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Prunella (interacts with) 4",
        "interaction" : "interacts with",
        "SUID" : 224,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "222",
        "source" : "186",
        "target" : "192",
        "shared_name" : "Vision of Arthur (interacts with) 4",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Vision of Arthur (interacts with) 4",
        "interaction" : "interacts with",
        "SUID" : 222,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "220",
        "source" : "184",
        "target" : "192",
        "shared_name" : "Vision of Buster (interacts with) 4",
        "countInScene" : 1,
        "shared_interaction" : "interacts with",
        "name" : "Vision of Buster (interacts with) 4",
        "interaction" : "interacts with",
        "SUID" : 220,
        "selected" : false
      },
      "selected" : false
    } ]
  }
}}